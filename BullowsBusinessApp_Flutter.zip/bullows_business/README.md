# Bullows Business Manager — Flutter App

## Features
- ✅ Milk Business: Sellers, Customers, Purchases, Sales, Reports
- ✅ Food Products: Products, Suppliers, Customers, Purchases, Sales, Reports
- ✅ Both businesses 100% separate — no data mixing
- ✅ SQLite local database (data never lost)
- ✅ Full CRUD: Add, Edit, Delete, Search, Filter
- ✅ Auto profit calculation
- ✅ Stock tracking per product
- ✅ Today / Week / Month / All-Time reports
- ✅ Bar charts for 7-day sales
- ✅ Top customers and suppliers ranking
- ✅ Works on Android 5.0+ (API 21+) and iOS

## Build APK (Android)

### Requirements
- Flutter SDK 3.10+ → https://flutter.dev/docs/get-started/install
- Android Studio → https://developer.android.com/studio
- Java 17+

### Steps
```bash
# 1. Install dependencies
cd bullows_business
flutter pub get

# 2. Build release APK
flutter build apk --release

# APK location:
# build/app/outputs/flutter-apk/app-release.apk
```

### Build for specific devices
```bash
# For older Android (armeabi-v7a)
flutter build apk --target-platform android-arm --release

# For modern Android (arm64)
flutter build apk --target-platform android-arm64 --release

# Split APKs (smaller size)
flutter build apk --split-per-abi --release
```

## Database
- Uses **SQLite** via `sqflite` package
- Data stored at: `/data/data/com.bullows.business/databases/bullows.db`
- 9 tables: milk_sellers, milk_customers, milk_purchases, milk_sales,
  food_products, food_suppliers, food_customers, food_purchases, food_sales

## Project Structure
```
lib/
├── main.dart              # App entry point
├── theme/app_theme.dart   # Colors & theme
├── db/db_helper.dart      # SQLite database (all CRUD)
├── models/                # Data models (9 files)
├── widgets/widgets.dart   # Shared UI components
└── screens/
    ├── home_screen.dart   # Home + bottom nav
    ├── milk/              # Milk business (6 screens)
    └── food/              # Food business (7 screens)
```
