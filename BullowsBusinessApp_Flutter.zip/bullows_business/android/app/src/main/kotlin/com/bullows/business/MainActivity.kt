
package com.bullows.business

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
