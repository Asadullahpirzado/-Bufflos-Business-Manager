
class MilkPurchase {
  final int? id;
  final int? sellerId;
  final String sellerName;
  final double quantity;
  final double pricePerLiter;
  final double totalCost;
  final String date;
  final String notes;

  MilkPurchase({this.id,this.sellerId,this.sellerName='',required this.quantity,
    required this.pricePerLiter,required this.totalCost,required this.date,this.notes=''});

  factory MilkPurchase.fromMap(Map<String,dynamic> m) => MilkPurchase(
    id:m['id'],sellerId:m['seller_id'],sellerName:m['seller_name']??'',
    quantity:(m['quantity']??0).toDouble(),pricePerLiter:(m['price_per_liter']??0).toDouble(),
    totalCost:(m['total_cost']??0).toDouble(),date:m['date']??'',notes:m['notes']??'',
  );

  Map<String,dynamic> toMap() => {
    if(id!=null)'id':id,
    'seller_id':sellerId,'seller_name':sellerName,'quantity':quantity,
    'price_per_liter':pricePerLiter,'total_cost':totalCost,'date':date,'notes':notes,
  };

  MilkPurchase copyWith({int? id,int? sellerId,String? sellerName,double? quantity,
    double? pricePerLiter,double? totalCost,String? date,String? notes}) =>
    MilkPurchase(id:id??this.id,sellerId:sellerId??this.sellerId,sellerName:sellerName??this.sellerName,
      quantity:quantity??this.quantity,pricePerLiter:pricePerLiter??this.pricePerLiter,
      totalCost:totalCost??this.totalCost,date:date??this.date,notes:notes??this.notes);
}
