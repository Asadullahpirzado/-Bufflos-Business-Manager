
class MilkSeller {
  final int? id;
  final String name;
  final String phone;
  final String address;
  final double pricePerLiter;

  MilkSeller({this.id, required this.name, this.phone='', this.address='', required this.pricePerLiter});

  factory MilkSeller.fromMap(Map<String,dynamic> m) => MilkSeller(
    id: m['id'], name: m['name'], phone: m['phone']??'',
    address: m['address']??'', pricePerLiter: (m['price_per_liter']??0).toDouble(),
  );

  Map<String,dynamic> toMap() => {
    if(id!=null) 'id':id,
    'name':name, 'phone':phone, 'address':address, 'price_per_liter':pricePerLiter,
  };

  MilkSeller copyWith({int? id, String? name, String? phone, String? address, double? pricePerLiter}) =>
    MilkSeller(id:id??this.id, name:name??this.name, phone:phone??this.phone,
      address:address??this.address, pricePerLiter:pricePerLiter??this.pricePerLiter);
}
