
class FoodSupplier {
  final int? id;
  final String name;
  final String phone;
  final String address;
  final String notes;

  FoodSupplier({this.id,required this.name,this.phone='',this.address='',this.notes=''});

  factory FoodSupplier.fromMap(Map<String,dynamic> m) => FoodSupplier(
    id:m['id'],name:m['name'],phone:m['phone']??'',address:m['address']??'',notes:m['notes']??'',
  );

  Map<String,dynamic> toMap() => {
    if(id!=null)'id':id,'name':name,'phone':phone,'address':address,'notes':notes,
  };

  FoodSupplier copyWith({int? id,String? name,String? phone,String? address,String? notes}) =>
    FoodSupplier(id:id??this.id,name:name??this.name,phone:phone??this.phone,
      address:address??this.address,notes:notes??this.notes);
}
