
class MilkCustomer {
  final int? id;
  final String name;
  final String phone;
  final String address;
  final double sellingPrice;

  MilkCustomer({this.id, required this.name, this.phone='', this.address='', required this.sellingPrice});

  factory MilkCustomer.fromMap(Map<String,dynamic> m) => MilkCustomer(
    id:m['id'], name:m['name'], phone:m['phone']??'',
    address:m['address']??'', sellingPrice:(m['selling_price']??0).toDouble(),
  );

  Map<String,dynamic> toMap() => {
    if(id!=null) 'id':id,
    'name':name,'phone':phone,'address':address,'selling_price':sellingPrice,
  };

  MilkCustomer copyWith({int? id,String? name,String? phone,String? address,double? sellingPrice}) =>
    MilkCustomer(id:id??this.id,name:name??this.name,phone:phone??this.phone,
      address:address??this.address,sellingPrice:sellingPrice??this.sellingPrice);
}
