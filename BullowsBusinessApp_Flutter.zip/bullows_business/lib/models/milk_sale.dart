
class MilkSale {
  final int? id;
  final int? customerId;
  final String customerName;
  final double quantity;
  final double pricePerLiter;
  final double totalAmount;
  final String date;
  final String notes;

  MilkSale({this.id,this.customerId,this.customerName='',required this.quantity,
    required this.pricePerLiter,required this.totalAmount,required this.date,this.notes=''});

  factory MilkSale.fromMap(Map<String,dynamic> m) => MilkSale(
    id:m['id'],customerId:m['customer_id'],customerName:m['customer_name']??'',
    quantity:(m['quantity']??0).toDouble(),pricePerLiter:(m['price_per_liter']??0).toDouble(),
    totalAmount:(m['total_amount']??0).toDouble(),date:m['date']??'',notes:m['notes']??'',
  );

  Map<String,dynamic> toMap() => {
    if(id!=null)'id':id,
    'customer_id':customerId,'customer_name':customerName,'quantity':quantity,
    'price_per_liter':pricePerLiter,'total_amount':totalAmount,'date':date,'notes':notes,
  };

  MilkSale copyWith({int? id,int? customerId,String? customerName,double? quantity,
    double? pricePerLiter,double? totalAmount,String? date,String? notes}) =>
    MilkSale(id:id??this.id,customerId:customerId??this.customerId,customerName:customerName??this.customerName,
      quantity:quantity??this.quantity,pricePerLiter:pricePerLiter??this.pricePerLiter,
      totalAmount:totalAmount??this.totalAmount,date:date??this.date,notes:notes??this.notes);
}
