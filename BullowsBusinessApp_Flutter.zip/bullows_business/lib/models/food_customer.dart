
class FoodCustomer {
  final int? id;
  final String name;
  final String phone;
  final String address;

  FoodCustomer({this.id,required this.name,this.phone='',this.address=''});

  factory FoodCustomer.fromMap(Map<String,dynamic> m) => FoodCustomer(
    id:m['id'],name:m['name'],phone:m['phone']??'',address:m['address']??'',
  );

  Map<String,dynamic> toMap() => {
    if(id!=null)'id':id,'name':name,'phone':phone,'address':address,
  };

  FoodCustomer copyWith({int? id,String? name,String? phone,String? address}) =>
    FoodCustomer(id:id??this.id,name:name??this.name,phone:phone??this.phone,address:address??this.address);
}
