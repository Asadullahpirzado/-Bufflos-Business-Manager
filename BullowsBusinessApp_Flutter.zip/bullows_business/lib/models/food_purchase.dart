
class FoodPurchase {
  final int? id;
  final int? supplierId;
  final String supplierName;
  final int? productId;
  final String productName;
  final String productUnit;
  final double quantity;
  final double pricePerUnit;
  final double totalCost;
  final String date;
  final String notes;

  FoodPurchase({this.id,this.supplierId,this.supplierName='',this.productId,
    this.productName='',this.productUnit='pcs',required this.quantity,
    required this.pricePerUnit,required this.totalCost,required this.date,this.notes=''});

  factory FoodPurchase.fromMap(Map<String,dynamic> m) => FoodPurchase(
    id:m['id'],supplierId:m['supplier_id'],supplierName:m['supplier_name']??'',
    productId:m['product_id'],productName:m['product_name']??'',productUnit:m['product_unit']??'pcs',
    quantity:(m['quantity']??0).toDouble(),pricePerUnit:(m['price_per_unit']??0).toDouble(),
    totalCost:(m['total_cost']??0).toDouble(),date:m['date']??'',notes:m['notes']??'',
  );

  Map<String,dynamic> toMap() => {
    if(id!=null)'id':id,
    'supplier_id':supplierId,'supplier_name':supplierName,'product_id':productId,
    'product_name':productName,'product_unit':productUnit,'quantity':quantity,
    'price_per_unit':pricePerUnit,'total_cost':totalCost,'date':date,'notes':notes,
  };

  FoodPurchase copyWith({int? id,int? supplierId,String? supplierName,int? productId,
    String? productName,String? productUnit,double? quantity,double? pricePerUnit,
    double? totalCost,String? date,String? notes}) =>
    FoodPurchase(id:id??this.id,supplierId:supplierId??this.supplierId,supplierName:supplierName??this.supplierName,
      productId:productId??this.productId,productName:productName??this.productName,productUnit:productUnit??this.productUnit,
      quantity:quantity??this.quantity,pricePerUnit:pricePerUnit??this.pricePerUnit,
      totalCost:totalCost??this.totalCost,date:date??this.date,notes:notes??this.notes);
}
