
class FoodSale {
  final int? id;
  final int? customerId;
  final String customerName;
  final int? productId;
  final String productName;
  final String productUnit;
  final double quantity;
  final double pricePerUnit;
  final double totalAmount;
  final String date;
  final String notes;

  FoodSale({this.id,this.customerId,this.customerName='',this.productId,
    this.productName='',this.productUnit='pcs',required this.quantity,
    required this.pricePerUnit,required this.totalAmount,required this.date,this.notes=''});

  factory FoodSale.fromMap(Map<String,dynamic> m) => FoodSale(
    id:m['id'],customerId:m['customer_id'],customerName:m['customer_name']??'',
    productId:m['product_id'],productName:m['product_name']??'',productUnit:m['product_unit']??'pcs',
    quantity:(m['quantity']??0).toDouble(),pricePerUnit:(m['price_per_unit']??0).toDouble(),
    totalAmount:(m['total_amount']??0).toDouble(),date:m['date']??'',notes:m['notes']??'',
  );

  Map<String,dynamic> toMap() => {
    if(id!=null)'id':id,
    'customer_id':customerId,'customer_name':customerName,'product_id':productId,
    'product_name':productName,'product_unit':productUnit,'quantity':quantity,
    'price_per_unit':pricePerUnit,'total_amount':totalAmount,'date':date,'notes':notes,
  };

  FoodSale copyWith({int? id,int? customerId,String? customerName,int? productId,
    String? productName,String? productUnit,double? quantity,double? pricePerUnit,
    double? totalAmount,String? date,String? notes}) =>
    FoodSale(id:id??this.id,customerId:customerId??this.customerId,customerName:customerName??this.customerName,
      productId:productId??this.productId,productName:productName??this.productName,productUnit:productUnit??this.productUnit,
      quantity:quantity??this.quantity,pricePerUnit:pricePerUnit??this.pricePerUnit,
      totalAmount:totalAmount??this.totalAmount,date:date??this.date,notes:notes??this.notes);
}
