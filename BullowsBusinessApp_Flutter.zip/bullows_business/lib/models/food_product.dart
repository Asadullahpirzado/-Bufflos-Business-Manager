
class FoodProduct {
  final int? id;
  final String name;
  final String category;
  final String unit;
  final String description;

  FoodProduct({this.id,required this.name,this.category='',this.unit='pcs',this.description=''});

  factory FoodProduct.fromMap(Map<String,dynamic> m) => FoodProduct(
    id:m['id'],name:m['name'],category:m['category']??'',unit:m['unit']??'pcs',description:m['description']??'',
  );

  Map<String,dynamic> toMap() => {
    if(id!=null)'id':id,'name':name,'category':category,'unit':unit,'description':description,
  };

  FoodProduct copyWith({int? id,String? name,String? category,String? unit,String? description}) =>
    FoodProduct(id:id??this.id,name:name??this.name,category:category??this.category,
      unit:unit??this.unit,description:description??this.description);
}
