
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/home_screen.dart';
import 'theme/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));
  runApp(const BullowsApp());
}

class BullowsApp extends StatelessWidget {
  const BullowsApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Bullows Business Manager',
    debugShowCheckedModeBanner: false,
    theme: AppTheme.light,
    home: const HomeScreen(),
  );
}
