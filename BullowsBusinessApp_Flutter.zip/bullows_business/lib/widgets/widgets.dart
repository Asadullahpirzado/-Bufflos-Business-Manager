
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../theme/app_theme.dart';

// ── Money formatter ──────────────────────────────────────────
String fmtRs(double v) => 'Rs.${NumberFormat('#,##0.00').format(v)}';
String fmtNum(double v) => NumberFormat('#,##0.##').format(v);
String todayStr() => DateFormat('yyyy-MM-dd').format(DateTime.now());
String monthStr() => DateFormat('yyyy-MM').format(DateTime.now());

// ── Gradient Stat Card ───────────────────────────────────────
class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final String? sub;
  final IconData icon;
  final List<Color> colors;
  const StatCard({super.key,required this.label,required this.value,this.sub,required this.icon,required this.colors});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      gradient: LinearGradient(colors:colors,begin:Alignment.topLeft,end:Alignment.bottomRight),
      borderRadius: BorderRadius.circular(16),
      boxShadow: [BoxShadow(color:colors.last.withOpacity(0.3),blurRadius:12,offset:const Offset(0,4))],
    ),
    child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
        Expanded(child:Text(label,style:const TextStyle(color:Colors.white70,fontSize:11,fontWeight:FontWeight.w700,letterSpacing:0.5),overflow:TextOverflow.ellipsis)),
        Icon(icon,color:Colors.white54,size:18),
      ]),
      const SizedBox(height:8),
      Text(value,style:const TextStyle(color:Colors.white,fontSize:18,fontWeight:FontWeight.w900),overflow:TextOverflow.ellipsis),
      if(sub!=null) ...[const SizedBox(height:2),Text(sub!,style:const TextStyle(color:Colors.white60,fontSize:11))],
    ]),
  );
}

// ── Info Row ─────────────────────────────────────────────────
class InfoRow extends StatelessWidget {
  final String label; final String value; final Color? valueColor;
  const InfoRow(this.label,this.value,{super.key,this.valueColor});
  @override
  Widget build(BuildContext context) => Padding(
    padding:const EdgeInsets.symmetric(vertical:4),
    child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
      Text(label,style:const TextStyle(color:AppColors.slateM,fontSize:13)),
      Text(value,style:TextStyle(fontWeight:FontWeight.w800,fontSize:13,color:valueColor??AppColors.slate)),
    ]),
  );
}

// ── Section Header ────────────────────────────────────────────
class SectionHeader extends StatelessWidget {
  final String title;
  const SectionHeader(this.title,{super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding:const EdgeInsets.only(bottom:8),
    child:Text(title.toUpperCase(),style:const TextStyle(fontSize:11,fontWeight:FontWeight.w900,color:AppColors.slateM,letterSpacing:1)),
  );
}

// ── AppCard ───────────────────────────────────────────────────
class AppCard extends StatelessWidget {
  final Widget child; final EdgeInsets? padding;
  const AppCard({super.key,required this.child,this.padding});
  @override
  Widget build(BuildContext context) => Container(
    padding:padding??const EdgeInsets.all(16),
    decoration:BoxDecoration(
      color:Colors.white,borderRadius:BorderRadius.circular(16),
      border:Border.all(color:const Color(0xFFE2E8F0)),
      boxShadow:[BoxShadow(color:Colors.black.withOpacity(0.03),blurRadius:8,offset:const Offset(0,2))],
    ),
    child:child,
  );
}

// ── Profit Badge ──────────────────────────────────────────────
class ProfitBadge extends StatelessWidget {
  final double value;
  const ProfitBadge(this.value,{super.key});
  @override
  Widget build(BuildContext context) {
    final pos=value>=0;
    return Container(
      padding:const EdgeInsets.symmetric(horizontal:10,vertical:4),
      decoration:BoxDecoration(
        color:pos?const Color(0xFFD1FAE5):const Color(0xFFFEE2E2),
        borderRadius:BorderRadius.circular(20),
      ),
      child:Text('${pos?"+":""}${fmtRs(value)}',
        style:TextStyle(color:pos?AppColors.emerald:AppColors.rose,fontSize:12,fontWeight:FontWeight.w800)),
    );
  }
}

// ── Badge Chip ────────────────────────────────────────────────
class BadgeChip extends StatelessWidget {
  final String label; final Color bg; final Color fg;
  const BadgeChip(this.label,{super.key,required this.bg,required this.fg});
  @override
  Widget build(BuildContext context) => Container(
    padding:const EdgeInsets.symmetric(horizontal:10,vertical:3),
    decoration:BoxDecoration(color:bg,borderRadius:BorderRadius.circular(20)),
    child:Text(label,style:TextStyle(color:fg,fontSize:11,fontWeight:FontWeight.w800)),
  );
}

// ── Empty State ───────────────────────────────────────────────
class EmptyState extends StatelessWidget {
  final String message; final IconData icon;
  const EmptyState({super.key,required this.message,required this.icon});
  @override
  Widget build(BuildContext context) => Center(
    child:Column(mainAxisSize:MainAxisSize.min,children:[
      Icon(icon,size:56,color:const Color(0xFFCBD5E1)),
      const SizedBox(height:12),
      Text(message,style:const TextStyle(color:AppColors.slateM,fontSize:14,fontWeight:FontWeight.w600)),
    ]),
  );
}

// ── Confirm Dialog ────────────────────────────────────────────
Future<bool> confirmDelete(BuildContext ctx, String msg) async {
  return await showDialog<bool>(
    context:ctx,
    builder:(_)=>AlertDialog(
      shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(20)),
      icon:const Icon(Icons.warning_rounded,color:AppColors.rose,size:40),
      title:const Text('Confirm Delete',style:TextStyle(fontWeight:FontWeight.w900)),
      content:Text(msg),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),
        ElevatedButton(
          style:ElevatedButton.styleFrom(backgroundColor:AppColors.rose),
          onPressed:()=>Navigator.pop(ctx,true),
          child:const Text('Delete'),
        ),
      ],
    ),
  )??false;
}

// ── Search Field ──────────────────────────────────────────────
class SearchField extends StatelessWidget {
  final TextEditingController ctrl; final String hint; final VoidCallback? onChanged;
  const SearchField({super.key,required this.ctrl,required this.hint,this.onChanged});
  @override
  Widget build(BuildContext context) => TextField(
    controller:ctrl,
    onChanged:(_)=>onChanged?.call(),
    decoration:InputDecoration(
      hintText:hint,
      prefixIcon:const Icon(Icons.search_rounded,color:AppColors.slateM),
      suffixIcon:ctrl.text.isNotEmpty?IconButton(icon:const Icon(Icons.clear),onPressed:(){ctrl.clear();onChanged?.call();}):null,
    ),
  );
}

// ── Mini Bar Chart ────────────────────────────────────────────
class MiniBarChart extends StatelessWidget {
  final List<MapEntry<String,double>> data;
  final Color color;
  const MiniBarChart({super.key,required this.data,required this.color});

  @override
  Widget build(BuildContext context) {
    final max=data.map((e)=>e.value).fold(0.0,(a,b)=>a>b?a:b);
    return SizedBox(
      height:100,
      child:Row(
        crossAxisAlignment:CrossAxisAlignment.end,
        children:data.map((e){
          final h=max>0?(e.value/max)*70:0.0;
          return Expanded(child:Column(mainAxisAlignment:MainAxisAlignment.end,children:[
            if(h>0) Text(e.value>999?'${(e.value/1000).toStringAsFixed(1)}k':e.value.toStringAsFixed(0),
              style:TextStyle(fontSize:8,color:color,fontWeight:FontWeight.w700)),
            const SizedBox(height:2),
            Container(height:h,margin:const EdgeInsets.symmetric(horizontal:2),
              decoration:BoxDecoration(color:color,borderRadius:BorderRadius.circular(4))),
            const SizedBox(height:4),
            Text(e.key,style:const TextStyle(fontSize:9,color:AppColors.slateM,fontWeight:FontWeight.w600)),
          ]));
        }).toList(),
      ),
    );
  }
}

// ── Period Filter ─────────────────────────────────────────────
class PeriodFilter extends StatelessWidget {
  final String selected;
  final Color activeColor;
  final void Function(String) onSelect;
  const PeriodFilter({super.key,required this.selected,required this.activeColor,required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final opts=[('today','Today'),('week','Week'),('month','Month'),('all','All Time')];
    return Row(children:opts.map((o){
      final active=selected==o.$1;
      return Expanded(child:GestureDetector(
        onTap:()=>onSelect(o.$1),
        child:AnimatedContainer(
          duration:const Duration(milliseconds:200),
          margin:const EdgeInsets.symmetric(horizontal:2),
          padding:const EdgeInsets.symmetric(vertical:8),
          decoration:BoxDecoration(
            color:active?activeColor:Colors.white,
            borderRadius:BorderRadius.circular(10),
            border:Border.all(color:active?activeColor:const Color(0xFFE2E8F0)),
          ),
          child:Text(o.$2,textAlign:TextAlign.center,
            style:TextStyle(fontSize:11,fontWeight:FontWeight.w800,color:active?Colors.white:AppColors.slateM)),
        ),
      ));
    }).toList());
  }
}

// ── Action Row (Edit + Delete) ────────────────────────────────
class ActionRow extends StatelessWidget {
  final VoidCallback onEdit; final VoidCallback onDelete;
  const ActionRow({super.key,required this.onEdit,required this.onDelete});
  @override
  Widget build(BuildContext context) => Row(mainAxisSize:MainAxisSize.min,children:[
    _btn(Icons.edit_rounded,const Color(0xFFEFF6FF),const Color(0xFF3B82F6),onEdit),
    const SizedBox(width:8),
    _btn(Icons.delete_rounded,const Color(0xFFFFF1F2),AppColors.rose,onDelete),
  ]);

  Widget _btn(IconData icon,Color bg,Color fg,VoidCallback fn) => GestureDetector(
    onTap:fn,
    child:Container(
      width:36,height:36,
      decoration:BoxDecoration(color:bg,borderRadius:BorderRadius.circular(10)),
      child:Icon(icon,color:fg,size:18),
    ),
  );
}

// ── Custom Text Field ─────────────────────────────────────────
class CustomField extends StatelessWidget {
  final String label;
  final TextEditingController ctrl;
  final TextInputType? keyboard;
  final String? hint;
  final int maxLines;
  const CustomField({super.key,required this.label,required this.ctrl,this.keyboard,this.hint,this.maxLines=1});
  @override
  Widget build(BuildContext context) => TextField(
    controller:ctrl,keyboardType:keyboard,maxLines:maxLines,
    decoration:InputDecoration(labelText:label,hintText:hint),
  );
}

// ── Dropdown Field ────────────────────────────────────────────
class DropdownField<T> extends StatelessWidget {
  final String label;
  final T? value;
  final List<DropdownMenuItem<T>> items;
  final void Function(T?) onChanged;
  const DropdownField({super.key,required this.label,required this.value,required this.items,required this.onChanged});
  @override
  Widget build(BuildContext context) => InputDecorator(
    decoration:InputDecoration(labelText:label),
    child:DropdownButtonHideUnderline(child:DropdownButton<T>(
      value:value,items:items,onChanged:onChanged,isDense:true,isExpanded:true,
    )),
  );
}

// ── Total Preview Card ────────────────────────────────────────
class TotalPreview extends StatelessWidget {
  final double qty; final double price; final Color color;
  const TotalPreview({super.key,required this.qty,required this.price,required this.color});
  @override
  Widget build(BuildContext context) {
    if(qty<=0||price<=0) return const SizedBox.shrink();
    return Container(
      padding:const EdgeInsets.all(14),
      decoration:BoxDecoration(
        color:color.withOpacity(0.08),
        borderRadius:BorderRadius.circular(12),
        border:Border.all(color:color.withOpacity(0.2)),
      ),
      child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[
        Icon(Icons.calculate_rounded,color:color,size:18),
        const SizedBox(width:8),
        Text('Total → ',style:TextStyle(color:color,fontWeight:FontWeight.w700,fontSize:13)),
        Text(fmtRs(qty*price),style:TextStyle(color:color,fontWeight:FontWeight.w900,fontSize:18)),
      ]),
    );
  }
}

// ── Save Button ───────────────────────────────────────────────
class SaveButton extends StatelessWidget {
  final String label; final VoidCallback onPressed; final Color? color;
  const SaveButton({super.key,required this.label,required this.onPressed,this.color});
  @override
  Widget build(BuildContext context) => SizedBox(
    width:double.infinity,
    child:ElevatedButton.icon(
      style:ElevatedButton.styleFrom(backgroundColor:color??AppColors.teal,padding:const EdgeInsets.symmetric(vertical:14)),
      onPressed:onPressed,
      icon:const Icon(Icons.check_rounded),
      label:Text(label,style:const TextStyle(fontSize:15,fontWeight:FontWeight.w800)),
    ),
  );
}

// ── Show snackbar helper ──────────────────────────────────────
void showSnack(BuildContext ctx,String msg,{bool error=false}){
  ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
    content:Text(msg,style:const TextStyle(fontWeight:FontWeight.w700)),
    backgroundColor:error?AppColors.rose:AppColors.emerald,
    behavior:SnackBarBehavior.floating,
    shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12)),
    margin:const EdgeInsets.all(16),
    duration:const Duration(seconds:2),
  ));
}
