
import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/all_models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';

class MilkDashboard extends StatefulWidget {
  const MilkDashboard({super.key});
  @override State<MilkDashboard> createState() => _MilkDashboardState();
}

class _MilkDashboardState extends State<MilkDashboard> {
  List<MilkPurchase> _purchases=[];
  List<MilkSale>     _sales=[];
  bool _loading=true;

  @override void initState(){super.initState();_load();}

  Future<void> _load() async {
    final p=await DB.i.getMilkPurchases();
    final s=await DB.i.getMilkSales();
    setState((){_purchases=p;_sales=s;_loading=false;});
  }

  @override
  Widget build(BuildContext context){
    if(_loading) return const Center(child:CircularProgressIndicator(color:AppColors.teal));
    final today=todayStr(); final month=monthStr();
    final totalCost  =_purchases.fold(0.0,(a,x)=>a+x.totalCost);
    final totalRev   =_sales.fold(0.0,(a,x)=>a+x.totalAmount);
    final profit     =totalRev-totalCost;
    final totalBought=_purchases.fold(0.0,(a,x)=>a+x.quantity);
    final totalSold  =_sales.fold(0.0,(a,x)=>a+x.quantity);
    final stock      =totalBought-totalSold;
    final todayRev   =_sales.where((x)=>x.date==today).fold(0.0,(a,x)=>a+x.totalAmount);
    final todayCost  =_purchases.where((x)=>x.date==today).fold(0.0,(a,x)=>a+x.totalCost);
    final monRev     =_sales.where((x)=>x.date.startsWith(month)).fold(0.0,(a,x)=>a+x.totalAmount);
    final monCost    =_purchases.where((x)=>x.date.startsWith(month)).fold(0.0,(a,x)=>a+x.totalCost);

    // Last 7 days chart data
    final last7=List.generate(7,(i){
      final d=DateTime.now().subtract(Duration(days:6-i));
      final s=d.toIso8601String().split('T')[0];
      final v=_sales.where((x)=>x.date==s).fold(0.0,(a,x)=>a+x.totalAmount);
      return MapEntry(['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][d.weekday%7],v);
    });

    return RefreshIndicator(
      onRefresh:_load,
      child:ListView(padding:const EdgeInsets.all(16),children:[
        // Stats grid
        GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
          crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.6,
          children:[
            StatCard(label:'Total Revenue',value:fmtRs(totalRev),icon:Icons.trending_up,
              colors:const[Color(0xFF10B981),Color(0xFF059669)]),
            StatCard(label:'Net Profit',value:fmtRs(profit),sub:profit>=0?'Profitable':'Loss',
              icon:Icons.bar_chart_rounded,
              colors:profit>=0?const[Color(0xFF0D9488),Color(0xFF0F766E)]:const[Color(0xFFF43F5E),Color(0xFFDC2626)]),
            StatCard(label:'Stock Left',value:'${fmtNum(stock)} L',sub:'Bought ${fmtNum(totalBought)} L',
              icon:Icons.inventory_2_rounded,colors:const[Color(0xFF3B82F6),Color(0xFF2563EB)]),
            StatCard(label:'Total Cost',value:fmtRs(totalCost),icon:Icons.shopping_cart_rounded,
              colors:const[Color(0xFF64748B),Color(0xFF475569)]),
          ],
        ),
        const SizedBox(height:16),

        // Today
        AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const SectionHeader("Today's Summary"),
          Row(children:[
            Expanded(child:_miniStat("Sales",fmtRs(todayRev),AppColors.emerald)),
            const SizedBox(width:12),
            Expanded(child:_miniStat("Purchase",fmtRs(todayCost),AppColors.teal)),
            const SizedBox(width:12),
            Expanded(child:_miniStat("Profit",fmtRs(todayRev-todayCost),(todayRev-todayCost)>=0?AppColors.emerald:AppColors.rose)),
          ]),
        ])),
        const SizedBox(height:12),

        // This month
        AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const SectionHeader("This Month"),
          Row(children:[
            Expanded(child:_miniStat("Revenue",fmtRs(monRev),AppColors.emerald)),
            const SizedBox(width:12),
            Expanded(child:_miniStat("Cost",fmtRs(monCost),AppColors.teal)),
            const SizedBox(width:12),
            Expanded(child:_miniStat("Profit",fmtRs(monRev-monCost),(monRev-monCost)>=0?AppColors.emerald:AppColors.rose)),
          ]),
        ])),
        const SizedBox(height:12),

        // 7-day chart
        AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const SectionHeader("Last 7 Days — Sales"),
          const SizedBox(height:8),
          MiniBarChart(data:last7,color:AppColors.teal),
        ])),
        const SizedBox(height:12),

        // Quick counts
        AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const SectionHeader("Records"),
          InfoRow('Purchase Entries','${_purchases.length}'),
          InfoRow('Sale Entries','${_sales.length}'),
          InfoRow('Total Bought','${fmtNum(totalBought)} L'),
          InfoRow('Total Sold','${fmtNum(totalSold)} L'),
          InfoRow('In Stock','${fmtNum(stock)} L',valueColor:stock<0?AppColors.rose:AppColors.teal),
        ])),
      ]),
    );
  }

  Widget _miniStat(String l,String v,Color c)=>Column(children:[
    Text(v,style:TextStyle(color:c,fontSize:13,fontWeight:FontWeight.w900),overflow:TextOverflow.ellipsis),
    const SizedBox(height:2),
    Text(l,style:const TextStyle(color:AppColors.slateM,fontSize:11)),
  ]);
}
