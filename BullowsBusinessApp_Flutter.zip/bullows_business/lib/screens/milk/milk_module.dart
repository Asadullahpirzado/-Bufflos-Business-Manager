
import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import 'milk_dashboard.dart';
import 'milk_sellers.dart';
import 'milk_customers.dart';
import 'milk_purchases.dart';
import 'milk_sales.dart';
import 'milk_reports.dart';

class MilkModule extends StatefulWidget {
  const MilkModule({super.key});
  @override State<MilkModule> createState() => _MilkModuleState();
}

class _MilkModuleState extends State<MilkModule> with SingleTickerProviderStateMixin {
  late TabController _tc;

  @override void initState() { super.initState(); _tc=TabController(length:6,vsync:this); }
  @override void dispose()   { _tc.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Row(children:[
        Icon(Icons.water_drop_rounded,color:AppColors.teal,size:22),
        SizedBox(width:8),
        Text('Milk Business'),
      ]),
      bottom: TabBar(
        controller: _tc,
        isScrollable: true,
        indicatorColor: AppColors.teal,
        labelColor: AppColors.teal,
        unselectedLabelColor: AppColors.slateM,
        labelStyle: const TextStyle(fontWeight:FontWeight.w800,fontSize:12),
        tabAlignment: TabAlignment.start,
        tabs: const [
          Tab(text:'Dashboard'),
          Tab(text:'Sellers'),
          Tab(text:'Customers'),
          Tab(text:'Purchases'),
          Tab(text:'Sales'),
          Tab(text:'Reports'),
        ],
      ),
    ),
    body: TabBarView(
      controller: _tc,
      children: const [
        MilkDashboard(),
        MilkSellers(),
        MilkCustomers(),
        MilkPurchases(),
        MilkSalesScreen(),
        MilkReports(),
      ],
    ),
  );
}
