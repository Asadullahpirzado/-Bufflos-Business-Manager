
import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/all_models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';

class MilkSellers extends StatefulWidget {
  const MilkSellers({super.key});
  @override State<MilkSellers> createState() => _MilkSellersState();
}

class _MilkSellersState extends State<MilkSellers> {
  List<MilkSeller> _all=[], _filtered=[];
  final _search=TextEditingController();

  @override void initState(){super.initState();_load();}
  @override void dispose(){_search.dispose();super.dispose();}

  Future<void> _load() async {
    final d=await DB.i.getMilkSellers();
    setState((){_all=d;_filter();});
  }

  void _filter(){
    final q=_search.text.toLowerCase();
    setState(()=>_filtered=_all.where((x)=>x.name.toLowerCase().contains(q)||x.phone.contains(q)).toList());
  }

  Future<void> _showForm([MilkSeller? sel]) async {
    final name=TextEditingController(text:sel?.name);
    final phone=TextEditingController(text:sel?.phone);
    final addr=TextEditingController(text:sel?.address);
    final price=TextEditingController(text:sel?.pricePerLiter.toString());

    await showModalBottomSheet(context:context,isScrollControlled:true,
      shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(24))),
      builder:(ctx)=>Padding(
        padding:EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(ctx).viewInsets.bottom+20),
        child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(sel==null?'Add Milk Seller':'Edit Seller',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
          const SizedBox(height:20),
          CustomField(label:'Seller Name *',ctrl:name),
          const SizedBox(height:12),
          CustomField(label:'Phone',ctrl:phone,keyboard:TextInputType.phone),
          const SizedBox(height:12),
          CustomField(label:'Address',ctrl:addr),
          const SizedBox(height:12),
          CustomField(label:'Purchase Price per Litre (Rs.) *',ctrl:price,keyboard:const TextInputType.numberWithOptions(decimal:true)),
          const SizedBox(height:20),
          SaveButton(label:sel==null?'Save Seller':'Update Seller',onPressed:()async{
            if(name.text.trim().isEmpty||price.text.trim().isEmpty){
              showSnack(context,'Name & price required',error:true); return;
            }
            final s=MilkSeller(
              id:sel?.id, name:name.text.trim(), phone:phone.text.trim(),
              address:addr.text.trim(), pricePerLiter:double.tryParse(price.text)??0,
            );
            if(sel==null) await DB.i.addMilkSeller(s); else await DB.i.updMilkSeller(s);
            if(ctx.mounted) Navigator.pop(ctx);
            _load();
            if(mounted) showSnack(context,sel==null?'Seller added!':'Updated!');
          }),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context)=>Scaffold(
    backgroundColor:AppColors.bg,
    body:Column(children:[
      Padding(padding:const EdgeInsets.all(16),child:SearchField(ctrl:_search,hint:'Search sellers…',onChanged:_filter)),
      Expanded(child:_filtered.isEmpty
        ?const EmptyState(message:'No milk sellers yet',icon:Icons.person_outline)
        :ListView.separated(
          padding:const EdgeInsets.fromLTRB(16,0,16,80),
          itemCount:_filtered.length,
          separatorBuilder:(_,__)=>const SizedBox(height:10),
          itemBuilder:(_,i){
            final x=_filtered[i];
            return AppCard(child:Row(children:[
              Container(width:46,height:46,decoration:BoxDecoration(color:AppColors.tealLt,borderRadius:BorderRadius.circular(12)),
                child:const Icon(Icons.person_rounded,color:AppColors.teal,size:24)),
              const SizedBox(width:12),
              Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text(x.name,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:15)),
                if(x.phone.isNotEmpty) Text(x.phone,style:const TextStyle(color:AppColors.slateM,fontSize:12)),
                if(x.address.isNotEmpty) Text(x.address,style:const TextStyle(color:AppColors.slateM,fontSize:12)),
                const SizedBox(height:4),
                BadgeChip('Buy: ${fmtRs(x.pricePerLiter)}/L',bg:AppColors.tealLt,fg:AppColors.tealDk),
              ])),
              ActionRow(
                onEdit:()=>_showForm(x),
                onDelete:()async{
                  if(await confirmDelete(context,'Delete seller "${x.name}"?')){
                    await DB.i.delMilkSeller(x.id!); _load();
                    if(mounted) showSnack(context,'Deleted');
                  }
                },
              ),
            ]));
          },
        ),
      ),
    ]),
    floatingActionButton: FloatingActionButton.extended(
      backgroundColor:AppColors.teal,
      onPressed:()=>_showForm(),
      icon:const Icon(Icons.add,color:Colors.white),
      label:const Text('Add Seller',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w800)),
    ),
  );
}
