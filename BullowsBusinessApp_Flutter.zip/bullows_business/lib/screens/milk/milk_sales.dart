
import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/all_models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';

class MilkSalesScreen extends StatefulWidget {
  const MilkSalesScreen({super.key});
  @override State<MilkSalesScreen> createState() => _MilkSalesScreenState();
}

class _MilkSalesScreenState extends State<MilkSalesScreen> {
  List<MilkSale>     _list=[];
  List<MilkCustomer> _customers=[];
  int? _filterCust;
  bool _loading=true;

  @override void initState(){super.initState();_load();}

  Future<void> _load() async {
    final s=await DB.i.getMilkSales(customerId:_filterCust);
    final c=await DB.i.getMilkCustomers();
    setState((){_list=s;_customers=c;_loading=false;});
  }

  Future<void> _showForm([MilkSale? rec]) async {
    MilkCustomer? selCust=rec!=null?_customers.firstWhere((c)=>c.id==rec.customerId,orElse:()=>_customers.first):null;
    final qty=TextEditingController(text:rec?.quantity.toString());
    final price=TextEditingController(text:rec?.pricePerLiter.toString());
    final dateCtrl=TextEditingController(text:rec?.date??todayStr());
    final notes=TextEditingController(text:rec?.notes);
    double qtyV=rec?.quantity??0, priceV=rec?.pricePerLiter??0;

    await showModalBottomSheet(context:context,isScrollControlled:true,
      shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(24))),
      builder:(ctx)=>StatefulBuilder(builder:(ctx,setS)=>SingleChildScrollView(
        padding:EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(ctx).viewInsets.bottom+20),
        child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(rec==null?'Add Milk Sale':'Edit Sale',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
          const SizedBox(height:20),
          DropdownField<MilkCustomer?>(
            label:'Customer / Shop *',value:selCust,
            items:[const DropdownMenuItem(value:null,child:Text('Select customer')),
              ..._customers.map((c)=>DropdownMenuItem(value:c,child:Text(c.name)))],
            onChanged:(v){setS(()=>selCust=v);if(v!=null){price.text=v.sellingPrice.toString();priceV=v.sellingPrice;}},
          ),
          const SizedBox(height:12),
          TextField(controller:qty,keyboardType:const TextInputType.numberWithOptions(decimal:true),
            decoration:const InputDecoration(labelText:'Quantity (Litres) *'),
            onChanged:(v){setS(()=>qtyV=double.tryParse(v)??0);}),
          const SizedBox(height:12),
          TextField(controller:price,keyboardType:const TextInputType.numberWithOptions(decimal:true),
            decoration:const InputDecoration(labelText:'Selling Price per Litre (Rs.) *'),
            onChanged:(v){setS(()=>priceV=double.tryParse(v)??0);}),
          const SizedBox(height:12),
          TextField(controller:dateCtrl,readOnly:true,decoration:const InputDecoration(labelText:'Date *',suffixIcon:Icon(Icons.calendar_today)),
            onTap:()async{final d=await showDatePicker(context:ctx,initialDate:DateTime.now(),firstDate:DateTime(2020),lastDate:DateTime(2030));if(d!=null)dateCtrl.text='${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';}),
          const SizedBox(height:12),
          TextField(controller:notes,decoration:const InputDecoration(labelText:'Notes'),maxLines:2),
          const SizedBox(height:12),
          TotalPreview(qty:qtyV,price:priceV,color:AppColors.emerald),
          const SizedBox(height:16),
          SaveButton(label:rec==null?'Save Sale':'Update',color:AppColors.emerald,onPressed:()async{
            if(selCust==null||qty.text.isEmpty||price.text.isEmpty){showSnack(context,'All fields required',error:true);return;}
            final qv=double.tryParse(qty.text)??0;
            final pv=double.tryParse(price.text)??0;
            final s=MilkSale(id:rec?.id,customerId:selCust!.id,customerName:selCust!.name,
              quantity:qv,pricePerLiter:pv,totalAmount:qv*pv,date:dateCtrl.text,notes:notes.text.trim());
            if(rec==null) await DB.i.addMilkSale(s); else await DB.i.updMilkSale(s);
            if(ctx.mounted) Navigator.pop(ctx);
            _load();
            if(mounted) showSnack(context,rec==null?'Sale saved!':'Updated!');
          }),
        ]),
      )),
    );
  }

  @override
  Widget build(BuildContext context){
    if(_loading) return const Center(child:CircularProgressIndicator(color:AppColors.teal));
    final total=_list.fold(0.0,(a,x)=>a+x.totalAmount);
    return Scaffold(
      backgroundColor:AppColors.bg,
      body:Column(children:[
        Padding(padding:const EdgeInsets.all(16),child:DropdownButtonFormField<int?>(
          value:_filterCust,
          decoration:const InputDecoration(labelText:'Filter by Customer',contentPadding:EdgeInsets.symmetric(horizontal:12,vertical:10)),
          items:[const DropdownMenuItem(value:null,child:Text('All Customers')),
            ..._customers.map((c)=>DropdownMenuItem(value:c.id,child:Text(c.name)))],
          onChanged:(v){setState(()=>_filterCust=v);_load();},
        )),
        if(_list.isNotEmpty) Container(margin:const EdgeInsets.symmetric(horizontal:16),padding:const EdgeInsets.all(12),
          decoration:BoxDecoration(color:const Color(0xFFD1FAE5),borderRadius:BorderRadius.circular(12)),
          child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
            Text('${_list.length} Records',style:const TextStyle(fontWeight:FontWeight.w700,color:AppColors.emerald)),
            Text('Total: ${fmtRs(total)}',style:const TextStyle(fontWeight:FontWeight.w900,color:AppColors.emerald)),
          ])),
        const SizedBox(height:8),
        Expanded(child:_list.isEmpty
          ?const EmptyState(message:'No milk sales recorded yet',icon:Icons.receipt_long_outlined)
          :ListView.separated(
            padding:const EdgeInsets.fromLTRB(16,0,16,80),
            itemCount:_list.length,
            separatorBuilder:(_,__)=>const SizedBox(height:10),
            itemBuilder:(_,i){
              final x=_list[i];
              return AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
                  Expanded(child:Text(x.customerName,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:15),overflow:TextOverflow.ellipsis)),
                  ActionRow(onEdit:()=>_showForm(x),onDelete:()async{
                    if(await confirmDelete(context,'Delete this sale?')){await DB.i.delMilkSale(x.id!);_load();if(mounted)showSnack(context,'Deleted');}
                  }),
                ]),
                const SizedBox(height:6),
                Row(children:[
                  BadgeChip(x.date,bg:const Color(0xFFF1F5F9),fg:AppColors.slateM),
                  const SizedBox(width:8),
                  Text('${fmtNum(x.quantity)} L × ${fmtRs(x.pricePerLiter)}',style:const TextStyle(fontSize:13,color:AppColors.slateM)),
                ]),
                const SizedBox(height:6),
                Text('Total: ${fmtRs(x.totalAmount)}',style:const TextStyle(fontSize:16,fontWeight:FontWeight.w900,color:AppColors.emerald)),
                if(x.notes.isNotEmpty)...[const SizedBox(height:4),Text(x.notes,style:const TextStyle(fontSize:12,color:AppColors.slateM,fontStyle:FontStyle.italic))],
              ]));
            },
          ),
        ),
      ]),
      floatingActionButton:FloatingActionButton.extended(
        backgroundColor:AppColors.emerald,onPressed:()=>_showForm(),
        icon:const Icon(Icons.add,color:Colors.white),label:const Text('Add Sale',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w800)),
      ),
    );
  }
}
