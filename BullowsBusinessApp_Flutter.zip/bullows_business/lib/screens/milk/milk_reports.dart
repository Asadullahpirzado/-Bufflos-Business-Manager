
import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/all_models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';

class MilkReports extends StatefulWidget {
  const MilkReports({super.key});
  @override State<MilkReports> createState() => _MilkReportsState();
}

class _MilkReportsState extends State<MilkReports> {
  List<MilkPurchase> _purchases=[];
  List<MilkSale>     _sales=[];
  String _period='month';
  bool _loading=true;

  @override void initState(){super.initState();_load();}

  Future<void> _load() async {
    final p=await DB.i.getMilkPurchases();
    final s=await DB.i.getMilkSales();
    setState((){_purchases=p;_sales=s;_loading=false;});
  }

  List<MilkSale>     get _fSales     => _filtered(_sales,     (x)=>x.date);
  List<MilkPurchase> get _fPurchases => _filteredP(_purchases,(x)=>x.date);

  List<T> _filtered<T>(List<T> list, String Function(T) date) {
    final now=todayStr(); final mon=monthStr();
    return list.where((x){
      final d=date(x);
      if(_period=='today') return d==now;
      if(_period=='week'){
        final w=DateTime.now().subtract(const Duration(days:6));
        return d.compareTo('${w.year}-${w.month.toString().padLeft(2,'0')}-${w.day.toString().padLeft(2,'0')}')>=0;
      }
      if(_period=='month') return d.startsWith(mon);
      return true;
    }).toList();
  }
  List<MilkPurchase> _filteredP(List<MilkPurchase> list,String Function(MilkPurchase) date){
    final now=todayStr();final mon=monthStr();
    return list.where((x){
      final d=date(x);
      if(_period=='today') return d==now;
      if(_period=='week'){final w=DateTime.now().subtract(const Duration(days:6));return d.compareTo('${w.year}-${w.month.toString().padLeft(2,'0')}-${w.day.toString().padLeft(2,'0')}')>=0;}
      if(_period=='month') return d.startsWith(mon);
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context){
    if(_loading) return const Center(child:CircularProgressIndicator(color:AppColors.teal));

    final fS=_fSales; final fP=_fPurchases;
    final pRev  =fS.fold(0.0,(a,x)=>a+x.totalAmount);
    final pCost =fP.fold(0.0,(a,x)=>a+x.totalCost);
    final pProfit=pRev-pCost;
    final pSoldL=fS.fold(0.0,(a,x)=>a+x.quantity);
    final pBoughtL=fP.fold(0.0,(a,x)=>a+x.quantity);

    final totalRev  =_sales.fold(0.0,(a,x)=>a+x.totalAmount);
    final totalCost =_purchases.fold(0.0,(a,x)=>a+x.totalCost);
    final totalBought=_purchases.fold(0.0,(a,x)=>a+x.quantity);
    final totalSold  =_sales.fold(0.0,(a,x)=>a+x.quantity);

    // 7-day chart
    final last7=List.generate(7,(i){
      final d=DateTime.now().subtract(Duration(days:6-i));
      final s=d.toIso8601String().split('T')[0];
      final v=_sales.where((x)=>x.date==s).fold(0.0,(a,x)=>a+x.totalAmount);
      return MapEntry(['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][d.weekday%7],v);
    });

    // Monthly map
    final mMap=<String,Map<String,double>>{};
    for(final x in _sales){final m=x.date.substring(0,7);(mMap[m]??={}); mMap[m]!['rev']=(mMap[m]!['rev']??0)+x.totalAmount;}
    for(final x in _purchases){final m=x.date.substring(0,7);mMap[m]??={};mMap[m]!['cost']=(mMap[m]!['cost']??0)+x.totalCost;}
    final months=mMap.keys.toList()..sort();final recentMonths=months.length>6?months.sublist(months.length-6):months;

    // Top customers
    final custMap=<String,double>{};
    for(final x in _sales) custMap[x.customerName]=(custMap[x.customerName]??0)+x.totalAmount;
    final topCusts=custMap.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));

    // Top sellers
    final selMap=<String,double>{};
    for(final x in _purchases) selMap[x.sellerName]=(selMap[x.sellerName]??0)+x.totalCost;
    final topSellers=selMap.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));

    return RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.all(16),children:[
      PeriodFilter(selected:_period,activeColor:AppColors.teal,onSelect:(p)=>setState(()=>_period=p)),
      const SizedBox(height:16),

      GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
        crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.6,children:[
          StatCard(label:'Revenue',value:fmtRs(pRev),icon:Icons.trending_up,colors:const[Color(0xFF10B981),Color(0xFF059669)]),
          StatCard(label:'Net Profit',value:fmtRs(pProfit),icon:Icons.bar_chart,
            colors:pProfit>=0?const[Color(0xFF0D9488),Color(0xFF0F766E)]:const[Color(0xFFF43F5E),Color(0xFFDC2626)]),
          StatCard(label:'Purchase Cost',value:fmtRs(pCost),icon:Icons.shopping_cart,colors:const[Color(0xFF3B82F6),Color(0xFF2563EB)]),
          StatCard(label:'Sold / Bought',value:'${fmtNum(pSoldL)} L',sub:'Bought: ${fmtNum(pBoughtL)} L',icon:Icons.inventory_2,colors:const[Color(0xFF64748B),Color(0xFF475569)]),
        ]),
      const SizedBox(height:16),

      AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('All-Time Milk Summary'),
        InfoRow('Total Revenue',fmtRs(totalRev),valueColor:AppColors.emerald),
        InfoRow('Total Cost',fmtRs(totalCost),valueColor:AppColors.teal),
        InfoRow('Net Profit',fmtRs(totalRev-totalCost),valueColor:(totalRev-totalCost)>=0?AppColors.emerald:AppColors.rose),
        const Divider(height:16),
        InfoRow('Total Purchased','${fmtNum(totalBought)} L'),
        InfoRow('Total Sold','${fmtNum(totalSold)} L'),
        InfoRow('Stock Left','${fmtNum(totalBought-totalSold)} L',valueColor:(totalBought-totalSold)<0?AppColors.rose:AppColors.teal),
      ])),
      const SizedBox(height:12),

      AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('Last 7 Days — Sales Revenue'),
        const SizedBox(height:8),
        MiniBarChart(data:last7,color:AppColors.teal),
      ])),
      const SizedBox(height:12),

      if(recentMonths.isNotEmpty) AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('Monthly Breakdown'),
        ...recentMonths.map((m){
          final d=mMap[m]!; final pr=(d['rev']??0)-(d['cost']??0);
          final dt=DateTime.parse('$m-01');
          return Padding(padding:const EdgeInsets.symmetric(vertical:6),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
              Text('${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][dt.month-1]} ${dt.year}',
                style:const TextStyle(fontWeight:FontWeight.w800,fontSize:13)),
              ProfitBadge(pr),
            ]),
            const SizedBox(height:4),
            Row(children:[
              Text('Sales: ',style:const TextStyle(color:AppColors.slateM,fontSize:12)),
              Text(fmtRs(d['rev']??0),style:const TextStyle(color:AppColors.emerald,fontWeight:FontWeight.w700,fontSize:12)),
              const SizedBox(width:12),
              Text('Cost: ',style:const TextStyle(color:AppColors.slateM,fontSize:12)),
              Text(fmtRs(d['cost']??0),style:const TextStyle(color:AppColors.teal,fontWeight:FontWeight.w700,fontSize:12)),
            ]),
            const Divider(height:12),
          ]));
        }),
      ])),
      const SizedBox(height:12),

      if(topCusts.isNotEmpty) AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('Top Customers by Revenue'),
        ...topCusts.take(5).toList().asMap().entries.map((e)=>Padding(
          padding:const EdgeInsets.symmetric(vertical:5),
          child:Row(children:[
            Container(width:26,height:26,decoration:BoxDecoration(color:AppColors.tealLt,borderRadius:BorderRadius.circular(8)),
              child:Center(child:Text('${e.key+1}',style:const TextStyle(fontWeight:FontWeight.w900,color:AppColors.teal,fontSize:12)))),
            const SizedBox(width:10),
            Expanded(child:Text(e.value.key,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13),overflow:TextOverflow.ellipsis)),
            Text(fmtRs(e.value.value),style:const TextStyle(fontWeight:FontWeight.w900,color:AppColors.teal,fontSize:13)),
          ]),
        )),
      ])),
      const SizedBox(height:12),

      if(topSellers.isNotEmpty) AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('Top Purchase Sellers'),
        ...topSellers.take(5).toList().asMap().entries.map((e)=>Padding(
          padding:const EdgeInsets.symmetric(vertical:5),
          child:Row(children:[
            Container(width:26,height:26,decoration:BoxDecoration(color:const Color(0xFFDBEAFE),borderRadius:BorderRadius.circular(8)),
              child:Center(child:Text('${e.key+1}',style:const TextStyle(fontWeight:FontWeight.w900,color:Color(0xFF3B82F6),fontSize:12)))),
            const SizedBox(width:10),
            Expanded(child:Text(e.value.key,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13),overflow:TextOverflow.ellipsis)),
            Text(fmtRs(e.value.value),style:const TextStyle(fontWeight:FontWeight.w900,color:Color(0xFF3B82F6),fontSize:13)),
          ]),
        )),
      ])),
      const SizedBox(height:24),
    ]));
  }
}
