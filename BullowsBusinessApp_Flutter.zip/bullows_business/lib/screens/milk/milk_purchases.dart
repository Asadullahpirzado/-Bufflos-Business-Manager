
import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/all_models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';

class MilkPurchases extends StatefulWidget {
  const MilkPurchases({super.key});
  @override State<MilkPurchases> createState() => _MilkPurchasesState();
}

class _MilkPurchasesState extends State<MilkPurchases> {
  List<MilkPurchase> _list=[];
  List<MilkSeller>   _sellers=[];
  int? _filterSeller;
  bool _loading=true;

  @override void initState(){super.initState();_load();}

  Future<void> _load() async {
    final p=await DB.i.getMilkPurchases(sellerId:_filterSeller);
    final s=await DB.i.getMilkSellers();
    setState((){_list=p;_sellers=s;_loading=false;});
  }

  Future<void> _showForm([MilkPurchase? rec]) async {
    MilkSeller? selSeller=rec!=null?_sellers.firstWhere((s)=>s.id==rec.sellerId,orElse:()=>_sellers.first):null;
    final qty=TextEditingController(text:rec?.quantity.toString());
    final price=TextEditingController(text:rec?.pricePerLiter.toString());
    final dateCtrl=TextEditingController(text:rec?.date??todayStr());
    final notes=TextEditingController(text:rec?.notes);
    double qtyV=rec?.quantity??0, priceV=rec?.pricePerLiter??0;

    await showModalBottomSheet(context:context,isScrollControlled:true,
      shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(24))),
      builder:(ctx)=>StatefulBuilder(builder:(ctx,setS)=>SingleChildScrollView(
        padding:EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(ctx).viewInsets.bottom+20),
        child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(rec==null?'Add Milk Purchase':'Edit Purchase',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
          const SizedBox(height:20),
          DropdownField<MilkSeller?>(
            label:'Seller *',value:selSeller,
            items:[const DropdownMenuItem(value:null,child:Text('Select seller')),
              ..._sellers.map((s)=>DropdownMenuItem(value:s,child:Text(s.name)))],
            onChanged:(v){setS(()=>selSeller=v);if(v!=null){price.text=v.pricePerLiter.toString();priceV=v.pricePerLiter;}},
          ),
          const SizedBox(height:12),
          TextField(controller:qty,keyboardType:const TextInputType.numberWithOptions(decimal:true),
            decoration:const InputDecoration(labelText:'Quantity (Litres) *'),
            onChanged:(v){setS(()=>qtyV=double.tryParse(v)??0);}),
          const SizedBox(height:12),
          TextField(controller:price,keyboardType:const TextInputType.numberWithOptions(decimal:true),
            decoration:const InputDecoration(labelText:'Price per Litre (Rs.) *'),
            onChanged:(v){setS(()=>priceV=double.tryParse(v)??0);}),
          const SizedBox(height:12),
          TextField(controller:dateCtrl,readOnly:true,decoration:const InputDecoration(labelText:'Date *',suffixIcon:Icon(Icons.calendar_today)),
            onTap:()async{final d=await showDatePicker(context:ctx,initialDate:DateTime.now(),firstDate:DateTime(2020),lastDate:DateTime(2030));if(d!=null)dateCtrl.text='${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';}),
          const SizedBox(height:12),
          TextField(controller:notes,decoration:const InputDecoration(labelText:'Notes'),maxLines:2),
          const SizedBox(height:12),
          TotalPreview(qty:qtyV,price:priceV,color:AppColors.teal),
          const SizedBox(height:16),
          SaveButton(label:rec==null?'Save Purchase':'Update',onPressed:()async{
            if(selSeller==null||qty.text.isEmpty||price.text.isEmpty){showSnack(context,'All fields required',error:true);return;}
            final qv=double.tryParse(qty.text)??0;
            final pv=double.tryParse(price.text)??0;
            final p=MilkPurchase(id:rec?.id,sellerId:selSeller!.id,sellerName:selSeller!.name,
              quantity:qv,pricePerLiter:pv,totalCost:qv*pv,date:dateCtrl.text,notes:notes.text.trim());
            if(rec==null) await DB.i.addMilkPurchase(p); else await DB.i.updMilkPurchase(p);
            if(ctx.mounted) Navigator.pop(ctx);
            _load();
            if(mounted) showSnack(context,rec==null?'Purchase saved!':'Updated!');
          }),
        ]),
      )),
    );
  }

  @override
  Widget build(BuildContext context){
    if(_loading) return const Center(child:CircularProgressIndicator(color:AppColors.teal));
    final total=_list.fold(0.0,(a,x)=>a+x.totalCost);
    return Scaffold(
      backgroundColor:AppColors.bg,
      body:Column(children:[
        Padding(padding:const EdgeInsets.all(16),child:Row(children:[
          Expanded(child:DropdownButtonFormField<int?>(
            value:_filterSeller,
            decoration:const InputDecoration(labelText:'Filter by Seller',contentPadding:EdgeInsets.symmetric(horizontal:12,vertical:10)),
            items:[const DropdownMenuItem(value:null,child:Text('All Sellers')),
              ..._sellers.map((s)=>DropdownMenuItem(value:s.id,child:Text(s.name)))],
            onChanged:(v){setState(()=>_filterSeller=v);_load();},
          )),
        ])),
        if(_list.isNotEmpty) Container(margin:const EdgeInsets.symmetric(horizontal:16),padding:const EdgeInsets.all(12),
          decoration:BoxDecoration(color:AppColors.tealLt,borderRadius:BorderRadius.circular(12)),
          child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
            Text('${_list.length} Records',style:const TextStyle(fontWeight:FontWeight.w700,color:AppColors.tealDk)),
            Text('Total: ${fmtRs(total)}',style:const TextStyle(fontWeight:FontWeight.w900,color:AppColors.tealDk)),
          ])),
        const SizedBox(height:8),
        Expanded(child:_list.isEmpty
          ?const EmptyState(message:'No purchase records yet',icon:Icons.inbox_outlined)
          :ListView.separated(
            padding:const EdgeInsets.fromLTRB(16,0,16,80),
            itemCount:_list.length,
            separatorBuilder:(_,__)=>const SizedBox(height:10),
            itemBuilder:(_,i){
              final x=_list[i];
              return AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
                  Expanded(child:Text(x.sellerName,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:15),overflow:TextOverflow.ellipsis)),
                  ActionRow(onEdit:()=>_showForm(x),onDelete:()async{
                    if(await confirmDelete(context,'Delete this purchase?')){await DB.i.delMilkPurchase(x.id!);_load();if(mounted)showSnack(context,'Deleted');}
                  }),
                ]),
                const SizedBox(height:6),
                Row(children:[
                  BadgeChip(x.date,bg:const Color(0xFFF1F5F9),fg:AppColors.slateM),
                  const SizedBox(width:8),
                  Text('${fmtNum(x.quantity)} L × ${fmtRs(x.pricePerLiter)}',style:const TextStyle(fontSize:13,color:AppColors.slateM)),
                ]),
                const SizedBox(height:6),
                Text('Total: ${fmtRs(x.totalCost)}',style:const TextStyle(fontSize:16,fontWeight:FontWeight.w900,color:AppColors.teal)),
                if(x.notes.isNotEmpty)...[const SizedBox(height:4),Text(x.notes,style:const TextStyle(fontSize:12,color:AppColors.slateM,fontStyle:FontStyle.italic))],
              ]));
            },
          ),
        ),
      ]),
      floatingActionButton:FloatingActionButton.extended(
        backgroundColor:AppColors.teal,onPressed:()=>_showForm(),
        icon:const Icon(Icons.add,color:Colors.white),label:const Text('Add Purchase',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w800)),
      ),
    );
  }
}
