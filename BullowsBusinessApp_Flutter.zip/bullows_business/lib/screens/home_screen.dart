
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../db/db_helper.dart';
import '../theme/app_theme.dart';
import '../widgets/widgets.dart';
import 'milk/milk_module.dart';
import 'food/food_module.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  final _pages = const [_HomePage(), MilkModule(), FoodModule()];

  @override
  Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index:_tab, children:_pages),
    bottomNavigationBar: BottomNavigationBar(
      currentIndex: _tab,
      onTap: (i)=>setState(()=>_tab=i),
      items: const [
        BottomNavigationBarItem(icon:Icon(Icons.home_rounded),label:'Home'),
        BottomNavigationBarItem(icon:Icon(Icons.water_drop_rounded),label:'Milk'),
        BottomNavigationBarItem(icon:Icon(Icons.storefront_rounded),label:'Food'),
      ],
    ),
  );
}

class _HomePage extends StatefulWidget {
  const _HomePage();
  @override State<_HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<_HomePage> {
  Map<String,double> _milkStats = {};
  Map<String,double> _foodStats = {};
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final mPurchases = await DB.i.getMilkPurchases();
    final mSales     = await DB.i.getMilkSales();
    final fPurchases = await DB.i.getFoodPurchases();
    final fSales     = await DB.i.getFoodSales();
    final today      = todayStr();
    final month      = monthStr();

    final mCost  = mPurchases.fold(0.0,(a,x)=>a+x.totalCost);
    final mRev   = mSales.fold(0.0,(a,x)=>a+x.totalAmount);
    final fCost  = fPurchases.fold(0.0,(a,x)=>a+x.totalCost);
    final fRev   = fSales.fold(0.0,(a,x)=>a+x.totalAmount);
    final mBought= mPurchases.fold(0.0,(a,x)=>a+x.quantity);
    final mSold  = mSales.fold(0.0,(a,x)=>a+x.quantity);

    setState((){
      _milkStats = {
        'revenue': mRev, 'cost': mCost, 'profit': mRev-mCost,
        'stock': mBought-mSold,
        'today': mSales.where((x)=>x.date==today).fold(0.0,(a,x)=>a+x.totalAmount),
        'month': mSales.where((x)=>x.date.startsWith(month)).fold(0.0,(a,x)=>a+x.totalAmount),
      };
      _foodStats = {
        'revenue': fRev, 'cost': fCost, 'profit': fRev-fCost,
        'today': fSales.where((x)=>x.date==today).fold(0.0,(a,x)=>a+x.totalAmount),
        'month': fSales.where((x)=>x.date.startsWith(month)).fold(0.0,(a,x)=>a+x.totalAmount),
      };
      _loading=false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: RefreshIndicator(
        onRefresh: _load,
        child: CustomScrollView(slivers:[
          SliverAppBar(
            expandedHeight: 160,
            pinned: true,
            backgroundColor: AppColors.teal,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors:[AppColors.teal, AppColors.tealDk],
                    begin:Alignment.topLeft, end:Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(child: Padding(
                  padding: const EdgeInsets.fromLTRB(20,20,20,0),
                  child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                    const Text('Bullows Business',style:TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.w900)),
                    const Text('Management Suite',style:TextStyle(color:Colors.white70,fontSize:13)),
                    const SizedBox(height:10),
                    Text(DateFormat('EEEE, d MMMM yyyy').format(DateTime.now()),
                      style:const TextStyle(color:Colors.white60,fontSize:12)),
                  ]),
                )),
              ),
            ),
          ),

          SliverPadding(padding:const EdgeInsets.all(16),sliver:SliverList(delegate:SliverChildListDelegate([
            if(_loading) const Center(child:CircularProgressIndicator()),
            if(!_loading)...[
              // Today cards
              const SectionHeader("Today's Sales"),
              Row(children:[
                Expanded(child:_todayCard("🥛 Milk",_milkStats['today']??0,AppColors.teal,AppColors.tealLt)),
                const SizedBox(width:12),
                Expanded(child:_todayCard("🍱 Food",_foodStats['today']??0,AppColors.amber,AppColors.amberLt)),
              ]),
              const SizedBox(height:20),

              // Milk Business Card
              const SectionHeader("Milk Business"),
              _bizCard(
                emoji:'🥛', title:'Milk Business', subtitle:'Import & Export',
                color:AppColors.teal,
                stats:[
                  ('Revenue',fmtRs(_milkStats['revenue']??0),AppColors.emerald),
                  ('Profit',fmtRs(_milkStats['profit']??0),(_milkStats['profit']??0)>=0?AppColors.teal:AppColors.rose),
                  ('This Month',fmtRs(_milkStats['month']??0),AppColors.slate),
                  ('Stock','${fmtNum(_milkStats['stock']??0)} L',AppColors.slate),
                ],
                onTap:()=>_goTab(context,1),
              ),
              const SizedBox(height:12),

              // Food Business Card
              const SectionHeader("Food Products Business"),
              _bizCard(
                emoji:'🍱', title:'Bullows Food Products', subtitle:'Import & Sales',
                color:AppColors.amber,
                stats:[
                  ('Revenue',fmtRs(_foodStats['revenue']??0),AppColors.emerald),
                  ('Profit',fmtRs(_foodStats['profit']??0),(_foodStats['profit']??0)>=0?AppColors.amber:AppColors.rose),
                  ('This Month',fmtRs(_foodStats['month']??0),AppColors.slate),
                  ('Cost',fmtRs(_foodStats['cost']??0),AppColors.slate),
                ],
                onTap:()=>_goTab(context,2),
              ),
              const SizedBox(height:20),
            ],
          ]))),
        ]),
      ),
    );
  }

  void _goTab(BuildContext ctx,int idx){
    final nav=ctx.findAncestorStateOfType<_HomeScreenState>();
    nav?.setState(()=>nav._tab=idx);
  }

  Widget _todayCard(String label,double v,Color color,Color bg)=>Container(
    padding:const EdgeInsets.all(16),
    decoration:BoxDecoration(color:bg,borderRadius:BorderRadius.circular(16),border:Border.all(color:color.withOpacity(0.2))),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(label,style:TextStyle(color:color,fontSize:12,fontWeight:FontWeight.w800)),
      const SizedBox(height:6),
      Text(fmtRs(v),style:TextStyle(color:color,fontSize:16,fontWeight:FontWeight.w900),overflow:TextOverflow.ellipsis),
    ]),
  );

  Widget _bizCard({
    required String emoji,required String title,required String subtitle,
    required Color color,required List<(String,String,Color)> stats,required VoidCallback onTap,
  })=>GestureDetector(
    onTap:onTap,
    child:AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[
        Container(width:50,height:50,
          decoration:BoxDecoration(gradient:LinearGradient(colors:[color,color.withOpacity(0.7)]),borderRadius:BorderRadius.circular(14)),
          child:Center(child:Text(emoji,style:const TextStyle(fontSize:24)))),
        const SizedBox(width:12),
        Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(title,style:const TextStyle(fontSize:15,fontWeight:FontWeight.w900,color:AppColors.slate)),
          Text(subtitle,style:const TextStyle(fontSize:12,color:AppColors.slateM)),
        ])),
        Icon(Icons.arrow_forward_ios_rounded,color:color,size:16),
      ]),
      const SizedBox(height:14),
      const Divider(height:1),
      const SizedBox(height:14),
      GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
        childAspectRatio:3.5,mainAxisSpacing:4,crossAxisSpacing:8,
        children:stats.map((s)=>Row(children:[
          Text('${s.$1}: ',style:const TextStyle(fontSize:12,color:AppColors.slateM)),
          Expanded(child:Text(s.$2,style:TextStyle(fontSize:12,fontWeight:FontWeight.w900,color:s.$3),overflow:TextOverflow.ellipsis)),
        ])).toList(),
      ),
    ])),
  );
}
