
import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/all_models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';

class FoodPurchases extends StatefulWidget {
  const FoodPurchases({super.key});
  @override State<FoodPurchases> createState() => _FoodPurchasesState();
}

class _FoodPurchasesState extends State<FoodPurchases> {
  List<FoodPurchase>  _list=[];
  List<FoodProduct>   _products=[];
  List<FoodSupplier>  _suppliers=[];
  int? _filterProduct;
  bool _loading=true;

  @override void initState(){super.initState();_load();}

  Future<void> _load() async {
    final pu=await DB.i.getFoodPurchases(productId:_filterProduct);
    final pr=await DB.i.getFoodProducts();
    final su=await DB.i.getFoodSuppliers();
    setState((){_list=pu;_products=pr;_suppliers=su;_loading=false;});
  }

  Future<void> _showForm([FoodPurchase? rec]) async {
    FoodProduct?  selProd=rec!=null&&_products.any((p)=>p.id==rec.productId)?_products.firstWhere((p)=>p.id==rec.productId):null;
    FoodSupplier? selSupp=rec!=null&&_suppliers.any((s)=>s.id==rec.supplierId)?_suppliers.firstWhere((s)=>s.id==rec.supplierId):null;
    final qty=TextEditingController(text:rec?.quantity.toString());
    final price=TextEditingController(text:rec?.pricePerUnit.toString());
    final dateCtrl=TextEditingController(text:rec?.date??todayStr());
    final notes=TextEditingController(text:rec?.notes);
    double qtyV=rec?.quantity??0, priceV=rec?.pricePerUnit??0;

    await showModalBottomSheet(context:context,isScrollControlled:true,
      shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(24))),
      builder:(ctx)=>StatefulBuilder(builder:(ctx,setS)=>SingleChildScrollView(
        padding:EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(ctx).viewInsets.bottom+20),
        child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(rec==null?'Add Food Purchase':'Edit Purchase',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
          const SizedBox(height:20),
          DropdownField<FoodSupplier?>(label:'Supplier *',value:selSupp,
            items:[const DropdownMenuItem(value:null,child:Text('Select supplier')),
              ..._suppliers.map((s)=>DropdownMenuItem(value:s,child:Text(s.name)))],
            onChanged:(v)=>setS(()=>selSupp=v)),
          const SizedBox(height:12),
          DropdownField<FoodProduct?>(label:'Product *',value:selProd,
            items:[const DropdownMenuItem(value:null,child:Text('Select product')),
              ..._products.map((p)=>DropdownMenuItem(value:p,child:Text(p.name)))],
            onChanged:(v)=>setS(()=>selProd=v)),
          const SizedBox(height:12),
          TextField(controller:qty,keyboardType:const TextInputType.numberWithOptions(decimal:true),
            decoration:InputDecoration(labelText:'Quantity (${selProd?.unit??'units'}) *'),
            onChanged:(v)=>setS(()=>qtyV=double.tryParse(v)??0)),
          const SizedBox(height:12),
          TextField(controller:price,keyboardType:const TextInputType.numberWithOptions(decimal:true),
            decoration:const InputDecoration(labelText:'Price per Unit (Rs.) *'),
            onChanged:(v)=>setS(()=>priceV=double.tryParse(v)??0)),
          const SizedBox(height:12),
          TextField(controller:dateCtrl,readOnly:true,
            decoration:const InputDecoration(labelText:'Date *',suffixIcon:Icon(Icons.calendar_today)),
            onTap:()async{final d=await showDatePicker(context:ctx,initialDate:DateTime.now(),firstDate:DateTime(2020),lastDate:DateTime(2030));if(d!=null)dateCtrl.text='${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';}),
          const SizedBox(height:12),
          TextField(controller:notes,decoration:const InputDecoration(labelText:'Notes'),maxLines:2),
          const SizedBox(height:12),
          TotalPreview(qty:qtyV,price:priceV,color:AppColors.amber),
          const SizedBox(height:16),
          SaveButton(label:rec==null?'Save Purchase':'Update',color:AppColors.amber,onPressed:()async{
            if(selSupp==null||selProd==null||qty.text.isEmpty||price.text.isEmpty){showSnack(context,'All fields required',error:true);return;}
            final qv=double.tryParse(qty.text)??0;final pv=double.tryParse(price.text)??0;
            final p=FoodPurchase(id:rec?.id,supplierId:selSupp!.id,supplierName:selSupp!.name,
              productId:selProd!.id,productName:selProd!.name,productUnit:selProd!.unit,
              quantity:qv,pricePerUnit:pv,totalCost:qv*pv,date:dateCtrl.text,notes:notes.text.trim());
            if(rec==null) await DB.i.addFoodPurchase(p); else await DB.i.updFoodPurchase(p);
            if(ctx.mounted) Navigator.pop(ctx);
            _load();
            if(mounted) showSnack(context,rec==null?'Purchase saved!':'Updated!');
          }),
        ]),
      )),
    );
  }

  @override
  Widget build(BuildContext context){
    if(_loading) return const Center(child:CircularProgressIndicator(color:AppColors.amber));
    final total=_list.fold(0.0,(a,x)=>a+x.totalCost);
    return Scaffold(
      backgroundColor:AppColors.bg,
      body:Column(children:[
        Padding(padding:const EdgeInsets.all(16),child:DropdownButtonFormField<int?>(
          value:_filterProduct,
          decoration:const InputDecoration(labelText:'Filter by Product',contentPadding:EdgeInsets.symmetric(horizontal:12,vertical:10)),
          items:[const DropdownMenuItem(value:null,child:Text('All Products')),
            ..._products.map((p)=>DropdownMenuItem(value:p.id,child:Text(p.name)))],
          onChanged:(v){setState(()=>_filterProduct=v);_load();},
        )),
        if(_list.isNotEmpty) Container(margin:const EdgeInsets.symmetric(horizontal:16),padding:const EdgeInsets.all(12),
          decoration:BoxDecoration(color:AppColors.amberLt,borderRadius:BorderRadius.circular(12)),
          child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
            Text('${_list.length} Records',style:const TextStyle(fontWeight:FontWeight.w700,color:AppColors.amberDk)),
            Text('Total: ${fmtRs(total)}',style:const TextStyle(fontWeight:FontWeight.w900,color:AppColors.amberDk)),
          ])),
        const SizedBox(height:8),
        Expanded(child:_list.isEmpty
          ?const EmptyState(message:'No purchase records yet',icon:Icons.inbox_outlined)
          :ListView.separated(
            padding:const EdgeInsets.fromLTRB(16,0,16,80),
            itemCount:_list.length,
            separatorBuilder:(_,__)=>const SizedBox(height:10),
            itemBuilder:(_,i){
              final x=_list[i];
              return AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
                  Expanded(child:Text(x.productName,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:15),overflow:TextOverflow.ellipsis)),
                  ActionRow(onEdit:()=>_showForm(x),onDelete:()async{
                    if(await confirmDelete(context,'Delete this purchase?')){await DB.i.delFoodPurchase(x.id!);_load();if(mounted)showSnack(context,'Deleted');}
                  }),
                ]),
                const SizedBox(height:4),
                Text(x.supplierName,style:const TextStyle(color:AppColors.slateM,fontSize:12)),
                const SizedBox(height:6),
                Row(children:[
                  BadgeChip(x.date,bg:const Color(0xFFF1F5F9),fg:AppColors.slateM),
                  const SizedBox(width:8),
                  Text('${fmtNum(x.quantity)} ${x.productUnit} × ${fmtRs(x.pricePerUnit)}',style:const TextStyle(fontSize:13,color:AppColors.slateM)),
                ]),
                const SizedBox(height:6),
                Text('Total: ${fmtRs(x.totalCost)}',style:const TextStyle(fontSize:16,fontWeight:FontWeight.w900,color:AppColors.amber)),
                if(x.notes.isNotEmpty)...[const SizedBox(height:4),Text(x.notes,style:const TextStyle(fontSize:12,color:AppColors.slateM,fontStyle:FontStyle.italic))],
              ]));
            },
          ),
        ),
      ]),
      floatingActionButton:FloatingActionButton.extended(
        backgroundColor:AppColors.amber,onPressed:()=>_showForm(),
        icon:const Icon(Icons.add,color:Colors.white),label:const Text('Add Purchase',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w800)),
      ),
    );
  }
}
