
import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/all_models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';

class FoodReports extends StatefulWidget {
  const FoodReports({super.key});
  @override State<FoodReports> createState() => _FoodReportsState();
}

class _FoodReportsState extends State<FoodReports> {
  List<FoodPurchase> _purchases=[];
  List<FoodSale>     _sales=[];
  List<FoodProduct>  _products=[];
  String _period='month';
  bool _loading=true;

  @override void initState(){super.initState();_load();}

  Future<void> _load() async {
    final p=await DB.i.getFoodPurchases();
    final s=await DB.i.getFoodSales();
    final pr=await DB.i.getFoodProducts();
    setState((){_purchases=p;_sales=s;_products=pr;_loading=false;});
  }

  List<T> _filter<T>(List<T> list, String Function(T) getDate){
    final now=todayStr(); final mon=monthStr();
    return list.where((x){
      final d=getDate(x);
      if(_period=='today') return d==now;
      if(_period=='week'){final w=DateTime.now().subtract(const Duration(days:6));return d.compareTo('${w.year}-${w.month.toString().padLeft(2,'0')}-${w.day.toString().padLeft(2,'0')}')>=0;}
      if(_period=='month') return d.startsWith(mon);
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context){
    if(_loading) return const Center(child:CircularProgressIndicator(color:AppColors.amber));

    final fS=_filter(_sales,(x)=>x.date);
    final fP=_filter(_purchases,(x)=>x.date);
    final pRev  =fS.fold(0.0,(a,x)=>a+x.totalAmount);
    final pCost =fP.fold(0.0,(a,x)=>a+x.totalCost);
    final pProfit=pRev-pCost;

    final totalRev =_sales.fold(0.0,(a,x)=>a+x.totalAmount);
    final totalCost=_purchases.fold(0.0,(a,x)=>a+x.totalCost);

    final last7=List.generate(7,(i){
      final d=DateTime.now().subtract(Duration(days:6-i));
      final s=d.toIso8601String().split('T')[0];
      final v=_sales.where((x)=>x.date==s).fold(0.0,(a,x)=>a+x.totalAmount);
      return MapEntry(['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][d.weekday%7],v);
    });

    // Per-product stats
    final prodStats=_products.map((p){
      final bought=_purchases.where((x)=>x.productId==p.id).fold(0.0,(a,x)=>a+x.quantity);
      final sold=_sales.where((x)=>x.productId==p.id).fold(0.0,(a,x)=>a+x.quantity);
      final rev=_sales.where((x)=>x.productId==p.id).fold(0.0,(a,x)=>a+x.totalAmount);
      final cost=_purchases.where((x)=>x.productId==p.id).fold(0.0,(a,x)=>a+x.totalCost);
      return (p,bought,sold,bought-sold,rev,cost,rev-cost);
    }).where((r)=>r.$2>0||r.$5>0).toList()..sort((a,b)=>b.$5.compareTo(a.$5));

    // Monthly
    final mMap=<String,Map<String,double>>{};
    for(final x in _sales){final m=x.date.substring(0,7);mMap[m]??={};mMap[m]!['rev']=(mMap[m]!['rev']??0)+x.totalAmount;}
    for(final x in _purchases){final m=x.date.substring(0,7);mMap[m]??={};mMap[m]!['cost']=(mMap[m]!['cost']??0)+x.totalCost;}
    final months=mMap.keys.toList()..sort();
    final recentMonths=months.length>6?months.sublist(months.length-6):months;

    // Top customers
    final custMap=<String,double>{};
    for(final x in _sales) custMap[x.customerName]=(custMap[x.customerName]??0)+x.totalAmount;
    final topCusts=custMap.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));

    // Top suppliers
    final suppMap=<String,double>{};
    for(final x in _purchases) suppMap[x.supplierName]=(suppMap[x.supplierName]??0)+x.totalCost;
    final topSupp=suppMap.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));

    return RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.all(16),children:[
      PeriodFilter(selected:_period,activeColor:AppColors.amber,onSelect:(p)=>setState(()=>_period=p)),
      const SizedBox(height:16),

      GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
        crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.6,children:[
          StatCard(label:'Revenue',value:fmtRs(pRev),icon:Icons.trending_up,colors:const[Color(0xFFF59E0B),Color(0xFFD97706)]),
          StatCard(label:'Net Profit',value:fmtRs(pProfit),icon:Icons.bar_chart,
            colors:pProfit>=0?const[Color(0xFF10B981),Color(0xFF059669)]:const[Color(0xFFF43F5E),Color(0xFFDC2626)]),
          StatCard(label:'Purchase Cost',value:fmtRs(pCost),icon:Icons.shopping_bag,colors:const[Color(0xFF8B5CF6),Color(0xFF7C3AED)]),
          StatCard(label:'Products',value:'${_products.length}',icon:Icons.category,colors:const[Color(0xFF3B82F6),Color(0xFF2563EB)]),
        ]),
      const SizedBox(height:16),

      AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('All-Time Food Summary'),
        InfoRow('Total Revenue',fmtRs(totalRev),valueColor:AppColors.emerald),
        InfoRow('Total Cost',fmtRs(totalCost),valueColor:AppColors.amber),
        InfoRow('Net Profit',fmtRs(totalRev-totalCost),valueColor:(totalRev-totalCost)>=0?AppColors.emerald:AppColors.rose),
        InfoRow('Total Transactions','${_purchases.length+_sales.length}'),
      ])),
      const SizedBox(height:12),

      AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('Last 7 Days — Sales'),
        const SizedBox(height:8),
        MiniBarChart(data:last7,color:AppColors.amber),
      ])),
      const SizedBox(height:12),

      if(prodStats.isNotEmpty) AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('Per-Product Breakdown'),
        ...prodStats.map((r)=>Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
            Expanded(child:Text(r.$1.name,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:13),overflow:TextOverflow.ellipsis)),
            ProfitBadge(r.$7),
          ]),
          const SizedBox(height:6),
          Row(children:[
            Expanded(child:_pStat('Revenue',fmtRs(r.$5),AppColors.emerald)),
            Expanded(child:_pStat('Sold','${fmtNum(r.$3)} ${r.$1.unit}',AppColors.amber)),
            Expanded(child:_pStat('Stock','${fmtNum(r.$4)} ${r.$1.unit}',r.$4<=0?AppColors.rose:AppColors.teal)),
          ]),
          const SizedBox(height:6),
          ClipRRect(borderRadius:BorderRadius.circular(4),child:LinearProgressIndicator(
            value:r.$2>0?(r.$3/r.$2).clamp(0.0,1.0):0,
            backgroundColor:const Color(0xFFF1F5F9),color:r.$4<=0?AppColors.rose:AppColors.amber,minHeight:5,
          )),
          const Divider(height:16),
        ]))),
      ])),
      const SizedBox(height:12),

      if(recentMonths.isNotEmpty) AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('Monthly Breakdown'),
        ...recentMonths.map((m){
          final d=mMap[m]!; final pr=(d['rev']??0)-(d['cost']??0);
          final dt=DateTime.parse('$m-01');
          return Padding(padding:const EdgeInsets.symmetric(vertical:6),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
              Text('${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][dt.month-1]} ${dt.year}',
                style:const TextStyle(fontWeight:FontWeight.w800,fontSize:13)),
              ProfitBadge(pr),
            ]),
            const SizedBox(height:4),
            Row(children:[
              Text('Sales: ',style:const TextStyle(color:AppColors.slateM,fontSize:12)),
              Text(fmtRs(d['rev']??0),style:const TextStyle(color:AppColors.emerald,fontWeight:FontWeight.w700,fontSize:12)),
              const SizedBox(width:12),
              Text('Cost: ',style:const TextStyle(color:AppColors.slateM,fontSize:12)),
              Text(fmtRs(d['cost']??0),style:const TextStyle(color:AppColors.amber,fontWeight:FontWeight.w700,fontSize:12)),
            ]),
            const Divider(height:12),
          ]));
        }),
      ])),
      const SizedBox(height:12),

      if(topCusts.isNotEmpty) AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('Top Customers'),
        ...topCusts.take(5).toList().asMap().entries.map((e)=>Padding(
          padding:const EdgeInsets.symmetric(vertical:5),
          child:Row(children:[
            Container(width:26,height:26,decoration:BoxDecoration(color:AppColors.amberLt,borderRadius:BorderRadius.circular(8)),
              child:Center(child:Text('${e.key+1}',style:const TextStyle(fontWeight:FontWeight.w900,color:AppColors.amber,fontSize:12)))),
            const SizedBox(width:10),
            Expanded(child:Text(e.value.key,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13),overflow:TextOverflow.ellipsis)),
            Text(fmtRs(e.value.value),style:const TextStyle(fontWeight:FontWeight.w900,color:AppColors.amber,fontSize:13)),
          ]),
        )),
      ])),
      const SizedBox(height:12),

      if(topSupp.isNotEmpty) AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('Top Suppliers by Purchase'),
        ...topSupp.take(5).toList().asMap().entries.map((e)=>Padding(
          padding:const EdgeInsets.symmetric(vertical:5),
          child:Row(children:[
            Container(width:26,height:26,decoration:BoxDecoration(color:const Color(0xFFDBEAFE),borderRadius:BorderRadius.circular(8)),
              child:Center(child:Text('${e.key+1}',style:const TextStyle(fontWeight:FontWeight.w900,color:Color(0xFF3B82F6),fontSize:12)))),
            const SizedBox(width:10),
            Expanded(child:Text(e.value.key,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13),overflow:TextOverflow.ellipsis)),
            Text(fmtRs(e.value.value),style:const TextStyle(fontWeight:FontWeight.w900,color:Color(0xFF3B82F6),fontSize:13)),
          ]),
        )),
      ])),
      const SizedBox(height:24),
    ]));
  }

  Widget _pStat(String l,String v,Color c)=>Column(children:[
    Text(v,style:TextStyle(color:c,fontSize:12,fontWeight:FontWeight.w900),overflow:TextOverflow.ellipsis,textAlign:TextAlign.center),
    Text(l,style:const TextStyle(color:AppColors.slateM,fontSize:10),textAlign:TextAlign.center),
  ]);
}
