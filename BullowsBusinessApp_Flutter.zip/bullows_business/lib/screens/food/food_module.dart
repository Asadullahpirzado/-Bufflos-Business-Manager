
import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import 'food_dashboard.dart';
import 'food_products.dart';
import 'food_suppliers.dart';
import 'food_customers.dart';
import 'food_purchases.dart';
import 'food_sales.dart';
import 'food_reports.dart';

class FoodModule extends StatefulWidget {
  const FoodModule({super.key});
  @override State<FoodModule> createState() => _FoodModuleState();
}

class _FoodModuleState extends State<FoodModule> with SingleTickerProviderStateMixin {
  late TabController _tc;
  @override void initState(){super.initState();_tc=TabController(length:7,vsync:this);}
  @override void dispose(){_tc.dispose();super.dispose();}

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Row(children:[
        Icon(Icons.storefront_rounded,color:AppColors.amber,size:22),
        SizedBox(width:8),
        Text('Food Products'),
      ]),
      bottom: TabBar(
        controller:_tc, isScrollable:true,
        indicatorColor:AppColors.amber, labelColor:AppColors.amber,
        unselectedLabelColor:AppColors.slateM,
        labelStyle:const TextStyle(fontWeight:FontWeight.w800,fontSize:12),
        tabAlignment:TabAlignment.start,
        tabs:const[
          Tab(text:'Dashboard'), Tab(text:'Products'), Tab(text:'Suppliers'),
          Tab(text:'Customers'), Tab(text:'Purchases'), Tab(text:'Sales'), Tab(text:'Reports'),
        ],
      ),
    ),
    body: TabBarView(controller:_tc,children:const[
      FoodDashboard(), FoodProducts(), FoodSuppliers(),
      FoodCustomers(), FoodPurchases(), FoodSalesScreen(), FoodReports(),
    ]),
  );
}
