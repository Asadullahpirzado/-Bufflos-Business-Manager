
import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/all_models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';

class FoodCustomers extends StatefulWidget {
  const FoodCustomers({super.key});
  @override State<FoodCustomers> createState() => _FoodCustomersState();
}

class _FoodCustomersState extends State<FoodCustomers> {
  List<FoodCustomer> _list=[], _filtered=[];
  final _search=TextEditingController();
  @override void initState(){super.initState();_load();}
  @override void dispose(){_search.dispose();super.dispose();}

  Future<void> _load() async {final d=await DB.i.getFoodCustomers();setState((){_list=d;_filter();});}
  void _filter(){final q=_search.text.toLowerCase();setState(()=>_filtered=_list.where((x)=>x.name.toLowerCase().contains(q)||x.phone.contains(q)).toList());}

  Future<void> _showForm([FoodCustomer? rec]) async {
    final name=TextEditingController(text:rec?.name);
    final phone=TextEditingController(text:rec?.phone);
    final addr=TextEditingController(text:rec?.address);
    await showModalBottomSheet(context:context,isScrollControlled:true,
      shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(24))),
      builder:(ctx)=>Padding(
        padding:EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(ctx).viewInsets.bottom+20),
        child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(rec==null?'Add Customer':'Edit Customer',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
          const SizedBox(height:20),
          CustomField(label:'Customer / Shop Name *',ctrl:name),
          const SizedBox(height:12),
          CustomField(label:'Phone',ctrl:phone,keyboard:TextInputType.phone),
          const SizedBox(height:12),
          CustomField(label:'Address',ctrl:addr),
          const SizedBox(height:20),
          SaveButton(label:rec==null?'Save Customer':'Update',color:AppColors.amber,onPressed:()async{
            if(name.text.trim().isEmpty){showSnack(context,'Name required',error:true);return;}
            final c=FoodCustomer(id:rec?.id,name:name.text.trim(),phone:phone.text.trim(),address:addr.text.trim());
            if(rec==null) await DB.i.addFoodCustomer(c); else await DB.i.updFoodCustomer(c);
            if(ctx.mounted) Navigator.pop(ctx);
            _load();
            if(mounted) showSnack(context,rec==null?'Customer added!':'Updated!');
          }),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context)=>Scaffold(
    backgroundColor:AppColors.bg,
    body:Column(children:[
      Padding(padding:const EdgeInsets.all(16),child:SearchField(ctrl:_search,hint:'Search customers…',onChanged:_filter)),
      Expanded(child:_filtered.isEmpty
        ?const EmptyState(message:'No customers yet',icon:Icons.storefront_outlined)
        :ListView.separated(
          padding:const EdgeInsets.fromLTRB(16,0,16,80),
          itemCount:_filtered.length,
          separatorBuilder:(_,__)=>const SizedBox(height:10),
          itemBuilder:(_,i){
            final x=_filtered[i];
            return AppCard(child:Row(children:[
              Container(width:46,height:46,decoration:BoxDecoration(color:const Color(0xFFD1FAE5),borderRadius:BorderRadius.circular(12)),
                child:const Icon(Icons.storefront_rounded,color:AppColors.emerald,size:24)),
              const SizedBox(width:12),
              Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text(x.name,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:15)),
                if(x.phone.isNotEmpty) Text(x.phone,style:const TextStyle(color:AppColors.slateM,fontSize:12)),
                if(x.address.isNotEmpty) Text(x.address,style:const TextStyle(color:AppColors.slateM,fontSize:12)),
              ])),
              ActionRow(onEdit:()=>_showForm(x),onDelete:()async{
                if(await confirmDelete(context,'Delete "${x.name}"?')){await DB.i.delFoodCustomer(x.id!);_load();if(mounted)showSnack(context,'Deleted');}
              }),
            ]));
          },
        ),
      ),
    ]),
    floatingActionButton:FloatingActionButton.extended(
      backgroundColor:AppColors.emerald,onPressed:()=>_showForm(),
      icon:const Icon(Icons.add,color:Colors.white),label:const Text('Add Customer',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w800)),
    ),
  );
}
