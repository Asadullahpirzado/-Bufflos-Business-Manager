
import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/all_models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';

class FoodSuppliers extends StatefulWidget {
  const FoodSuppliers({super.key});
  @override State<FoodSuppliers> createState() => _FoodSuppliersState();
}

class _FoodSuppliersState extends State<FoodSuppliers> {
  List<FoodSupplier> _list=[];
  final _search=TextEditingController();
  List<FoodSupplier> _filtered=[];
  @override void initState(){super.initState();_load();}
  @override void dispose(){_search.dispose();super.dispose();}

  Future<void> _load() async {final d=await DB.i.getFoodSuppliers();setState((){_list=d;_filter();});}
  void _filter(){final q=_search.text.toLowerCase();setState(()=>_filtered=_list.where((x)=>x.name.toLowerCase().contains(q)||x.phone.contains(q)).toList());}

  Future<void> _showForm([FoodSupplier? rec]) async {
    final name=TextEditingController(text:rec?.name);
    final phone=TextEditingController(text:rec?.phone);
    final addr=TextEditingController(text:rec?.address);
    final notes=TextEditingController(text:rec?.notes);
    await showModalBottomSheet(context:context,isScrollControlled:true,
      shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(24))),
      builder:(ctx)=>Padding(
        padding:EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(ctx).viewInsets.bottom+20),
        child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(rec==null?'Add Supplier':'Edit Supplier',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
          const SizedBox(height:20),
          CustomField(label:'Supplier Name *',ctrl:name),
          const SizedBox(height:12),
          CustomField(label:'Phone',ctrl:phone,keyboard:TextInputType.phone),
          const SizedBox(height:12),
          CustomField(label:'Address',ctrl:addr),
          const SizedBox(height:12),
          CustomField(label:'Notes',ctrl:notes,maxLines:2),
          const SizedBox(height:20),
          SaveButton(label:rec==null?'Save Supplier':'Update',color:AppColors.amber,onPressed:()async{
            if(name.text.trim().isEmpty){showSnack(context,'Name required',error:true);return;}
            final s=FoodSupplier(id:rec?.id,name:name.text.trim(),phone:phone.text.trim(),address:addr.text.trim(),notes:notes.text.trim());
            if(rec==null) await DB.i.addFoodSupplier(s); else await DB.i.updFoodSupplier(s);
            if(ctx.mounted) Navigator.pop(ctx);
            _load();
            if(mounted) showSnack(context,rec==null?'Supplier added!':'Updated!');
          }),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context)=>Scaffold(
    backgroundColor:AppColors.bg,
    body:Column(children:[
      Padding(padding:const EdgeInsets.all(16),child:SearchField(ctrl:_search,hint:'Search suppliers…',onChanged:_filter)),
      Expanded(child:_filtered.isEmpty
        ?const EmptyState(message:'No suppliers yet',icon:Icons.person_outline)
        :ListView.separated(
          padding:const EdgeInsets.fromLTRB(16,0,16,80),
          itemCount:_filtered.length,
          separatorBuilder:(_,__)=>const SizedBox(height:10),
          itemBuilder:(_,i){
            final x=_filtered[i];
            return AppCard(child:Row(children:[
              Container(width:46,height:46,decoration:BoxDecoration(color:AppColors.amberLt,borderRadius:BorderRadius.circular(12)),
                child:const Icon(Icons.person_rounded,color:AppColors.amber,size:24)),
              const SizedBox(width:12),
              Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text(x.name,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:15)),
                if(x.phone.isNotEmpty) Text(x.phone,style:const TextStyle(color:AppColors.slateM,fontSize:12)),
                if(x.address.isNotEmpty) Text(x.address,style:const TextStyle(color:AppColors.slateM,fontSize:12)),
                if(x.notes.isNotEmpty) Text(x.notes,style:const TextStyle(color:AppColors.slateM,fontSize:12,fontStyle:FontStyle.italic)),
              ])),
              ActionRow(onEdit:()=>_showForm(x),onDelete:()async{
                if(await confirmDelete(context,'Delete "${x.name}"?')){await DB.i.delFoodSupplier(x.id!);_load();if(mounted)showSnack(context,'Deleted');}
              }),
            ]));
          },
        ),
      ),
    ]),
    floatingActionButton:FloatingActionButton.extended(
      backgroundColor:AppColors.amber,onPressed:()=>_showForm(),
      icon:const Icon(Icons.add,color:Colors.white),label:const Text('Add Supplier',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w800)),
    ),
  );
}
