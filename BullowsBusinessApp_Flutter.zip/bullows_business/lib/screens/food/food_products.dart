
import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/all_models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';

class FoodProducts extends StatefulWidget {
  const FoodProducts({super.key});
  @override State<FoodProducts> createState() => _FoodProductsState();
}

class _FoodProductsState extends State<FoodProducts> {
  List<FoodProduct> _all=[], _filtered=[];
  final _search=TextEditingController();
  @override void initState(){super.initState();_load();}
  @override void dispose(){_search.dispose();super.dispose();}

  Future<void> _load() async {
    final d=await DB.i.getFoodProducts();
    setState((){_all=d;_filter();});
  }
  void _filter(){final q=_search.text.toLowerCase();setState(()=>_filtered=_all.where((x)=>x.name.toLowerCase().contains(q)).toList());}

  Future<void> _showForm([FoodProduct? rec]) async {
    final name=TextEditingController(text:rec?.name);
    final cat=TextEditingController(text:rec?.category);
    final unit=TextEditingController(text:rec?.unit??'pcs');
    final desc=TextEditingController(text:rec?.description);
    await showModalBottomSheet(context:context,isScrollControlled:true,
      shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(24))),
      builder:(ctx)=>Padding(
        padding:EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(ctx).viewInsets.bottom+20),
        child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(rec==null?'Add Product':'Edit Product',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
          const SizedBox(height:20),
          CustomField(label:'Product Name *',ctrl:name),
          const SizedBox(height:12),
          CustomField(label:'Category',ctrl:cat,hint:'Dairy / Snacks / Beverages…'),
          const SizedBox(height:12),
          CustomField(label:'Unit',ctrl:unit,hint:'kg / pcs / box / bottle…'),
          const SizedBox(height:12),
          CustomField(label:'Description',ctrl:desc,maxLines:2),
          const SizedBox(height:20),
          SaveButton(label:rec==null?'Add Product':'Update',color:AppColors.amber,onPressed:()async{
            if(name.text.trim().isEmpty){showSnack(context,'Name required',error:true);return;}
            final p=FoodProduct(id:rec?.id,name:name.text.trim(),category:cat.text.trim(),unit:unit.text.trim().isEmpty?'pcs':unit.text.trim(),description:desc.text.trim());
            if(rec==null) await DB.i.addFoodProduct(p); else await DB.i.updFoodProduct(p);
            if(ctx.mounted) Navigator.pop(ctx);
            _load();
            if(mounted) showSnack(context,rec==null?'Product added!':'Updated!');
          }),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context)=>Scaffold(
    backgroundColor:AppColors.bg,
    body:Column(children:[
      Padding(padding:const EdgeInsets.all(16),child:SearchField(ctrl:_search,hint:'Search products…',onChanged:_filter)),
      Expanded(child:_filtered.isEmpty
        ?const EmptyState(message:'No products added yet',icon:Icons.category_outlined)
        :ListView.separated(
          padding:const EdgeInsets.fromLTRB(16,0,16,80),
          itemCount:_filtered.length,
          separatorBuilder:(_,__)=>const SizedBox(height:10),
          itemBuilder:(_,i){
            final x=_filtered[i];
            return AppCard(child:Row(children:[
              Container(width:46,height:46,decoration:BoxDecoration(color:AppColors.amberLt,borderRadius:BorderRadius.circular(12)),
                child:const Icon(Icons.inventory_2_rounded,color:AppColors.amber,size:24)),
              const SizedBox(width:12),
              Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text(x.name,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:15)),
                const SizedBox(height:4),
                Row(children:[
                  if(x.category.isNotEmpty)...[BadgeChip(x.category,bg:AppColors.amberLt,fg:AppColors.amberDk),const SizedBox(width:6)],
                  if(x.unit.isNotEmpty) BadgeChip('per ${x.unit}',bg:const Color(0xFFDBEAFE),fg:const Color(0xFF2563EB)),
                ]),
                if(x.description.isNotEmpty)...[const SizedBox(height:4),Text(x.description,style:const TextStyle(color:AppColors.slateM,fontSize:12))],
              ])),
              ActionRow(onEdit:()=>_showForm(x),onDelete:()async{
                if(await confirmDelete(context,'Delete "${x.name}"?')){await DB.i.delFoodProduct(x.id!);_load();if(mounted)showSnack(context,'Deleted');}
              }),
            ]));
          },
        ),
      ),
    ]),
    floatingActionButton:FloatingActionButton.extended(
      backgroundColor:AppColors.amber,onPressed:()=>_showForm(),
      icon:const Icon(Icons.add,color:Colors.white),label:const Text('Add Product',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w800)),
    ),
  );
}
