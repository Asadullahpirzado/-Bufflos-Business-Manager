
import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/all_models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';

class FoodDashboard extends StatefulWidget {
  const FoodDashboard({super.key});
  @override State<FoodDashboard> createState() => _FoodDashboardState();
}

class _FoodDashboardState extends State<FoodDashboard> {
  List<FoodPurchase> _purchases=[];
  List<FoodSale>     _sales=[];
  List<FoodProduct>  _products=[];
  bool _loading=true;

  @override void initState(){super.initState();_load();}

  Future<void> _load() async {
    final p=await DB.i.getFoodPurchases();
    final s=await DB.i.getFoodSales();
    final pr=await DB.i.getFoodProducts();
    setState((){_purchases=p;_sales=s;_products=pr;_loading=false;});
  }

  @override
  Widget build(BuildContext context){
    if(_loading) return const Center(child:CircularProgressIndicator(color:AppColors.amber));
    final today=todayStr(); final month=monthStr();
    final totalCost =_purchases.fold(0.0,(a,x)=>a+x.totalCost);
    final totalRev  =_sales.fold(0.0,(a,x)=>a+x.totalAmount);
    final profit    =totalRev-totalCost;
    final todayRev  =_sales.where((x)=>x.date==today).fold(0.0,(a,x)=>a+x.totalAmount);
    final todayCost =_purchases.where((x)=>x.date==today).fold(0.0,(a,x)=>a+x.totalCost);
    final monRev    =_sales.where((x)=>x.date.startsWith(month)).fold(0.0,(a,x)=>a+x.totalAmount);
    final monCost   =_purchases.where((x)=>x.date.startsWith(month)).fold(0.0,(a,x)=>a+x.totalCost);

    final last7=List.generate(7,(i){
      final d=DateTime.now().subtract(Duration(days:6-i));
      final s=d.toIso8601String().split('T')[0];
      final v=_sales.where((x)=>x.date==s).fold(0.0,(a,x)=>a+x.totalAmount);
      return MapEntry(['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][d.weekday%7],v);
    });

    // Stock per product
    final stockRows=_products.map((p){
      final bought=_purchases.where((x)=>x.productId==p.id).fold(0.0,(a,x)=>a+x.quantity);
      final sold=_sales.where((x)=>x.productId==p.id).fold(0.0,(a,x)=>a+x.quantity);
      return (p,bought,sold,bought-sold);
    }).where((r)=>r.$2>0).toList();

    return RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.all(16),children:[
      GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
        crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.6,children:[
          StatCard(label:'Total Revenue',value:fmtRs(totalRev),icon:Icons.trending_up,colors:const[Color(0xFFF59E0B),Color(0xFFD97706)]),
          StatCard(label:'Net Profit',value:fmtRs(profit),icon:Icons.bar_chart,
            colors:profit>=0?const[Color(0xFF10B981),Color(0xFF059669)]:const[Color(0xFFF43F5E),Color(0xFFDC2626)]),
          StatCard(label:'Total Cost',value:fmtRs(totalCost),icon:Icons.shopping_bag_rounded,colors:const[Color(0xFF8B5CF6),Color(0xFF7C3AED)]),
          StatCard(label:'Products',value:'${_products.length}',icon:Icons.category_rounded,colors:const[Color(0xFF3B82F6),Color(0xFF2563EB)]),
        ]),
      const SizedBox(height:16),

      AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader("Today's Summary"),
        Row(children:[
          Expanded(child:_m("Sales",fmtRs(todayRev),AppColors.amber)),
          const SizedBox(width:12),
          Expanded(child:_m("Purchase",fmtRs(todayCost),const Color(0xFF8B5CF6))),
          const SizedBox(width:12),
          Expanded(child:_m("Profit",fmtRs(todayRev-todayCost),(todayRev-todayCost)>=0?AppColors.emerald:AppColors.rose)),
        ]),
      ])),
      const SizedBox(height:12),

      AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader("This Month"),
        Row(children:[
          Expanded(child:_m("Revenue",fmtRs(monRev),AppColors.amber)),
          const SizedBox(width:12),
          Expanded(child:_m("Cost",fmtRs(monCost),const Color(0xFF8B5CF6))),
          const SizedBox(width:12),
          Expanded(child:_m("Profit",fmtRs(monRev-monCost),(monRev-monCost)>=0?AppColors.emerald:AppColors.rose)),
        ]),
      ])),
      const SizedBox(height:12),

      AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('Last 7 Days — Sales'),
        const SizedBox(height:8),
        MiniBarChart(data:last7,color:AppColors.amber),
      ])),
      const SizedBox(height:12),

      if(stockRows.isNotEmpty) AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SectionHeader('Stock Overview'),
        const SizedBox(height:4),
        ...stockRows.map((r)=>Padding(padding:const EdgeInsets.symmetric(vertical:6),child:Column(children:[
          Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
            Expanded(child:Text(r.$1.name,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13),overflow:TextOverflow.ellipsis)),
            Text('${fmtNum(r.$4)} ${r.$1.unit}',
              style:TextStyle(fontWeight:FontWeight.w900,fontSize:13,color:r.$4<=0?AppColors.rose:AppColors.emerald)),
          ]),
          const SizedBox(height:4),
          ClipRRect(borderRadius:BorderRadius.circular(4),child:LinearProgressIndicator(
            value:r.$2>0?(r.$3/r.$2).clamp(0.0,1.0):0,
            backgroundColor:const Color(0xFFF1F5F9),color:r.$4<=0?AppColors.rose:AppColors.amber,minHeight:6,
          )),
          const SizedBox(height:2),
          Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
            Text('Sold: ${fmtNum(r.$3)}',style:const TextStyle(fontSize:11,color:AppColors.slateM)),
            Text('Bought: ${fmtNum(r.$2)}',style:const TextStyle(fontSize:11,color:AppColors.slateM)),
          ]),
        ]))),
      ])),
      const SizedBox(height:24),
    ]));
  }
  Widget _m(String l,String v,Color c)=>Column(children:[
    Text(v,style:TextStyle(color:c,fontSize:13,fontWeight:FontWeight.w900),overflow:TextOverflow.ellipsis),
    const SizedBox(height:2),
    Text(l,style:const TextStyle(color:AppColors.slateM,fontSize:11)),
  ]);
}
