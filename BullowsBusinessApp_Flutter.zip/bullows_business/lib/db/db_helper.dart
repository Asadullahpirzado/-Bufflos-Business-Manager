
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/all_models.dart';

class DB {
  static final DB i = DB._();
  DB._();
  static Database? _db;

  Future<Database> get db async {
    _db ??= await _init();
    return _db!;
  }

  Future<Database> _init() async {
    final path = join(await getDatabasesPath(), 'bullows.db');
    return openDatabase(path, version: 1, onCreate: _create);
  }

  Future<void> _create(Database db, int v) async {
    await db.execute('''CREATE TABLE milk_sellers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      address TEXT,
      price_per_liter REAL NOT NULL
    )''');
    await db.execute('''CREATE TABLE milk_customers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      address TEXT,
      selling_price REAL NOT NULL
    )''');
    await db.execute('''CREATE TABLE milk_purchases(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      seller_id INTEGER,
      seller_name TEXT,
      quantity REAL NOT NULL,
      price_per_liter REAL NOT NULL,
      total_cost REAL NOT NULL,
      date TEXT NOT NULL,
      notes TEXT
    )''');
    await db.execute('''CREATE TABLE milk_sales(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_id INTEGER,
      customer_name TEXT,
      quantity REAL NOT NULL,
      price_per_liter REAL NOT NULL,
      total_amount REAL NOT NULL,
      date TEXT NOT NULL,
      notes TEXT
    )''');
    await db.execute('''CREATE TABLE food_products(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      category TEXT,
      unit TEXT,
      description TEXT
    )''');
    await db.execute('''CREATE TABLE food_suppliers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      address TEXT,
      notes TEXT
    )''');
    await db.execute('''CREATE TABLE food_customers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      address TEXT
    )''');
    await db.execute('''CREATE TABLE food_purchases(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      supplier_id INTEGER,
      supplier_name TEXT,
      product_id INTEGER,
      product_name TEXT,
      product_unit TEXT,
      quantity REAL NOT NULL,
      price_per_unit REAL NOT NULL,
      total_cost REAL NOT NULL,
      date TEXT NOT NULL,
      notes TEXT
    )''');
    await db.execute('''CREATE TABLE food_sales(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_id INTEGER,
      customer_name TEXT,
      product_id INTEGER,
      product_name TEXT,
      product_unit TEXT,
      quantity REAL NOT NULL,
      price_per_unit REAL NOT NULL,
      total_amount REAL NOT NULL,
      date TEXT NOT NULL,
      notes TEXT
    )''');
  }

  // ── MILK SELLERS ────────────────────────────────────
  Future<int>         addMilkSeller(MilkSeller x)    async => (await db).insert('milk_sellers', x.toMap());
  Future<int>         updMilkSeller(MilkSeller x)    async => (await db).update('milk_sellers', x.toMap(), where:'id=?', whereArgs:[x.id]);
  Future<int>         delMilkSeller(int id)           async => (await db).delete('milk_sellers', where:'id=?', whereArgs:[id]);
  Future<List<MilkSeller>> getMilkSellers()           async => ((await db).query('milk_sellers', orderBy:'name')).then((r)=>r.map(MilkSeller.fromMap).toList());

  // ── MILK CUSTOMERS ──────────────────────────────────
  Future<int>           addMilkCustomer(MilkCustomer x) async => (await db).insert('milk_customers', x.toMap());
  Future<int>           updMilkCustomer(MilkCustomer x) async => (await db).update('milk_customers', x.toMap(), where:'id=?', whereArgs:[x.id]);
  Future<int>           delMilkCustomer(int id)          async => (await db).delete('milk_customers', where:'id=?', whereArgs:[id]);
  Future<List<MilkCustomer>> getMilkCustomers()          async => ((await db).query('milk_customers', orderBy:'name')).then((r)=>r.map(MilkCustomer.fromMap).toList());

  // ── MILK PURCHASES ──────────────────────────────────
  Future<int>            addMilkPurchase(MilkPurchase x) async => (await db).insert('milk_purchases', x.toMap());
  Future<int>            updMilkPurchase(MilkPurchase x) async => (await db).update('milk_purchases', x.toMap(), where:'id=?', whereArgs:[x.id]);
  Future<int>            delMilkPurchase(int id)          async => (await db).delete('milk_purchases', where:'id=?', whereArgs:[id]);
  Future<List<MilkPurchase>> getMilkPurchases({int? sellerId}) async {
    final d = await db;
    final r = sellerId!=null
      ? await d.query('milk_purchases', where:'seller_id=?', whereArgs:[sellerId], orderBy:'date DESC')
      : await d.query('milk_purchases', orderBy:'date DESC');
    return r.map(MilkPurchase.fromMap).toList();
  }

  // ── MILK SALES ──────────────────────────────────────
  Future<int>         addMilkSale(MilkSale x)    async => (await db).insert('milk_sales', x.toMap());
  Future<int>         updMilkSale(MilkSale x)    async => (await db).update('milk_sales', x.toMap(), where:'id=?', whereArgs:[x.id]);
  Future<int>         delMilkSale(int id)         async => (await db).delete('milk_sales', where:'id=?', whereArgs:[id]);
  Future<List<MilkSale>> getMilkSales({int? customerId}) async {
    final d = await db;
    final r = customerId!=null
      ? await d.query('milk_sales', where:'customer_id=?', whereArgs:[customerId], orderBy:'date DESC')
      : await d.query('milk_sales', orderBy:'date DESC');
    return r.map(MilkSale.fromMap).toList();
  }

  // ── FOOD PRODUCTS ───────────────────────────────────
  Future<int>           addFoodProduct(FoodProduct x) async => (await db).insert('food_products', x.toMap());
  Future<int>           updFoodProduct(FoodProduct x) async => (await db).update('food_products', x.toMap(), where:'id=?', whereArgs:[x.id]);
  Future<int>           delFoodProduct(int id)         async => (await db).delete('food_products', where:'id=?', whereArgs:[id]);
  Future<List<FoodProduct>> getFoodProducts()          async => ((await db).query('food_products', orderBy:'name')).then((r)=>r.map(FoodProduct.fromMap).toList());

  // ── FOOD SUPPLIERS ──────────────────────────────────
  Future<int>            addFoodSupplier(FoodSupplier x) async => (await db).insert('food_suppliers', x.toMap());
  Future<int>            updFoodSupplier(FoodSupplier x) async => (await db).update('food_suppliers', x.toMap(), where:'id=?', whereArgs:[x.id]);
  Future<int>            delFoodSupplier(int id)          async => (await db).delete('food_suppliers', where:'id=?', whereArgs:[id]);
  Future<List<FoodSupplier>> getFoodSuppliers()           async => ((await db).query('food_suppliers', orderBy:'name')).then((r)=>r.map(FoodSupplier.fromMap).toList());

  // ── FOOD CUSTOMERS ──────────────────────────────────
  Future<int>            addFoodCustomer(FoodCustomer x) async => (await db).insert('food_customers', x.toMap());
  Future<int>            updFoodCustomer(FoodCustomer x) async => (await db).update('food_customers', x.toMap(), where:'id=?', whereArgs:[x.id]);
  Future<int>            delFoodCustomer(int id)          async => (await db).delete('food_customers', where:'id=?', whereArgs:[id]);
  Future<List<FoodCustomer>> getFoodCustomers()           async => ((await db).query('food_customers', orderBy:'name')).then((r)=>r.map(FoodCustomer.fromMap).toList());

  // ── FOOD PURCHASES ──────────────────────────────────
  Future<int>            addFoodPurchase(FoodPurchase x) async => (await db).insert('food_purchases', x.toMap());
  Future<int>            updFoodPurchase(FoodPurchase x) async => (await db).update('food_purchases', x.toMap(), where:'id=?', whereArgs:[x.id]);
  Future<int>            delFoodPurchase(int id)          async => (await db).delete('food_purchases', where:'id=?', whereArgs:[id]);
  Future<List<FoodPurchase>> getFoodPurchases({int? productId}) async {
    final d = await db;
    final r = productId!=null
      ? await d.query('food_purchases', where:'product_id=?', whereArgs:[productId], orderBy:'date DESC')
      : await d.query('food_purchases', orderBy:'date DESC');
    return r.map(FoodPurchase.fromMap).toList();
  }

  // ── FOOD SALES ──────────────────────────────────────
  Future<int>         addFoodSale(FoodSale x)    async => (await db).insert('food_sales', x.toMap());
  Future<int>         updFoodSale(FoodSale x)    async => (await db).update('food_sales', x.toMap(), where:'id=?', whereArgs:[x.id]);
  Future<int>         delFoodSale(int id)         async => (await db).delete('food_sales', where:'id=?', whereArgs:[id]);
  Future<List<FoodSale>> getFoodSales({int? productId}) async {
    final d = await db;
    final r = productId!=null
      ? await d.query('food_sales', where:'product_id=?', whereArgs:[productId], orderBy:'date DESC')
      : await d.query('food_sales', orderBy:'date DESC');
    return r.map(FoodSale.fromMap).toList();
  }
}
